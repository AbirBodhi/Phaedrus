# -*- coding: utf-8 -*-
"""
Created on Thu Nov 14 21:55:30 2024

@author: AbirB
"""


def openPrediction(fileName):
    """
    open file fileName
    """
    fp = open(fileName, "r")
    process = True
    predictions, groundTruth = list(), list()
    currA, currB = list(), list()
    for line in fp:
        if 'Correct = ' in line:
            process = True
            if currA:
                predictions.append(currA)
                groundTruth.append(currB)
                currA, currB = list(), list()
        if process and "=?" in line:
            #print(line)
            b = line.split(" ")
            try:
                currA.append(int(b[0]))
            except ValueError:
                continue
            try:
                currB.append(int(b[-1]))
            except ValueError:
                currA.pop()
                continue
    return predictions, groundTruth

def getHotFunctions(prediction):
    """
    """
    x = max(prediction)
    hots, currHot = list(), list()
    process = False
    for t in prediction:
        if t == x:
            if not currHot:
                process = True
            else:
                hots.append(currHot)
                currHot = list()
                process = False
        elif process:
            currHot.append(t)
    return hots        
        

def openEncodings(fileName):
    """
    opens the encoding file
    """
    allEncodings = dict()
    fp = open(fileName, "r")
    buffer = fp.readlines()
    for i in range(len(buffer)):
        if "path encodings:" in buffer[i]:
            bName = buffer[i - 2]
            #print(bName)
            d = buffer[i].strip()[17:].split(",")
            d[0] = d[0][1:]
            d[-1] = d[-1][:-1]
            x = dict()
            for p in d:
                x[int(p.split(":")[1].strip())] = p.split(":")[0].strip()[1:-1]
            allEncodings[bName.strip()] = x
    #print(allEncodings)
    return allEncodings        

def performDecoding(sequence, encodeDict):
    """
    """
    newSequence = list()
    for t in sequence:
        if t in encodeDict:
           p = [int(x) for x in encodeDict[t].split("-")]
           #print(p)
           newSequence += p
        else:
           newSequence.append(t) 
        
    return newSequence        
            

if __name__ == "__main__":
    fileN1 = "/home/bodhi/Research_Repos/morpheus/results/hotFunctions/encodings/pathEncodings.log"
    bEncodings = openEncodings(fileN1)
    
    #fileN = "C://Users//AbirB//Downloads//hotFunctions//predictions//519.lbm_r_pred.log"
    prefix = "/home/bodhi/Research_Repos/morpheus/results/hotFunctions/predictions/"
    for b, encode in bEncodings.items():
        print(b)
        fileN = prefix + b + "_pred.log"
        predictions, groundTruth = openPrediction(fileN)
        #small
        decodedSeq = performDecoding(predictions[0], encode)
        with open
        print(decodedSeq)
        #medium
        decodedSeq = performDecoding(predictions[1], encode)
        print(decodedSeq)
        #large
        decodedSeq = performDecoding(predictions[2], encode)
        print(decodedSeq)
