#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 18 10:00:23 2024

@author: bodhisatwa
"""

import pathUtils
import collections
import torch

def openUncompressed(fileName):
    """
    open the original uncompressed logs with all tokens in one line
    """
    fp = open(fileName, "r")
    tokens = None
    for line in fp:
        tokens = line.split(",")
        tokens = tokens[:-1]
        tokens = [int(x) for x in tokens]
    return tokens

def openLogs(fileName):
    """
    opens the compressed logs (could be either aug or unaug)
    returns the list of tokens
    """
    fp = open(fileName, "r")
    tokens = list()
    for line in fp:
      t = int(line.strip())
      tokens.append(t)
    return tokens   
        
def tokensToTensor(tokens, max_val):
    """
    convert the tokens to one-hot encoded tensors
    return tensors
    """
    #max_val = max(tokens)
    #max_val = 190
    print("max_val = ", max_val)
    tensor = torch.zeros(len(tokens), 1, max_val + 1)
    for i in range(len(tokens)):
        tensor[i][0][tokens[i]] = 1
    return tensor    

def prepareData(seqData):
    """
    Create the source and target from a sequence
    Input: Tensor
    Output: (X, Y)
    """
    N, a, b = seqData.shape
    data = list()
    for i in range(N - 1):
        data.append((seqData[i, :, :], seqData[i + 1, :, :]))
    last = torch.zeros(a, b)    
    data.append((seqData[N - 1, :, :],last))
    return data

def tensorToToken(tensor):
    """
    Converts the tensors to tokens
    Useful for decoding predictions
    """
    preds = list()
    B, _, _ = tensor.shape
    for i in range(B):
        print(torch.argmax(tensor[i][0][:]))
        preds.append(torch.argmax(tensor[i][0][:]))
    return preds    

def unrollNewPaths(newPaths):
    """
    returns path tokens from the list of lists 
    """
    newTokens = list()
    for path in newPaths:
        #unroll them into newTokens
        newTokens += path    
    return newTokens

def generateAugmentedProfile(bench):
    """
    generates the additional paths not seen in source trace
    """
    
    sourcefile = pathUtils.logRoot + "/unaugmented/" + bench + "/" + bench + "_small.txt"
    destfile1 = pathUtils.logRoot + "/unaugmented/" + bench + "/" + bench + "_medium.txt"
    destfile2 = pathUtils.logRoot + "/unaugmented/" + bench + "/" + bench + "_large.txt"
    
    newPaths = getAugmentedPaths(sourcefile, destfile1)
    newPaths += getAugmentedPaths(sourcefile, destfile2)
    newPaths = [list(x) for x in set(tuple(x) for x in newPaths)]
    print("new Paths = ", newPaths)
    print("total new paths = ", len(newPaths))
    print("--------------------------------------")

    newTokens = unrollNewPaths(newPaths)
    return newTokens


def getAugmentedPaths(source, reference):
    """
    generated the unseen paths in source from reference trace
    """
    #tokenize both source and reference (library function available)
    sourceTokens = openLogs(source)
    refTokens = openLogs(reference)
    
    #get the hashMap for source to check for tokens present
    sourceMap = collections.Counter(sourceTokens)
    
    addPaths, aPath = list(), list()
    i = 0
    
    while i < len(refTokens):
        #print("aPath = ", aPath)
        if sourceMap[refTokens[i]] != 0:
            #token is already present
            #stop the current to-be augmented path
            #and store it in addPaths
            if aPath:
               #ends at the seen token
               aPath.append(refTokens[i])
               addPaths.append(aPath)
               aPath = list()
            i += 1
        else:
            #print(refTokens[i-1], "not present")
            #also add the token in sourceMap
            sourceMap[refTokens[i]] = 1
            #add the token in the to-be augmented path
            if not aPath and i - 1 >= 0:
                #create a new to-be augmented path
                #starts with the last seen token
                aPath.append(refTokens[i-1])
            aPath.append(refTokens[i])
            i += 1
            
    #store any residual to-be augmented paths        
    if aPath:
        addPaths.append(aPath)
    
    return addPaths

           
    
            