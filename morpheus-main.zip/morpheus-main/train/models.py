#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 18 11:31:41 2024

@author: bodhisatwa
"""

import torch.nn as nn

#dropout = 0.2
#learning_rate = 1e-3 
#EPOCHS = 10
#BATCH_SIZE = 1

class VanillaRNN(nn.Module):
    """ 
    An implementation of vanilla RNN using Pytorch Linear layers and activations.   
    """

    def __init__(self, input_size, hidden_size, output_size):
        """ Init function for VanillaRNN class
            Args:
                input_size (int): the number of features in the inputs.
                hidden_size (int): the size of the hidden layer
                output_size (int): the size of the output layer

            Returns: 
                None
        """
        super(VanillaRNN, self).__init__()

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        #self.embedding_dim = embedding_dim
        #self.vocab_size = vocab_size
            
        #self.l0 = nn.Embedding(num_embeddings = self.output_size, embedding_dim = 3)
        self.l1 = nn.RNN(input_size = self.input_size, hidden_size = self.hidden_size, batch_first = True)
        self.l2 = nn.Linear(in_features = self.hidden_size, out_features = self.output_size)
        self.l3 = nn.LogSoftmax(dim=-1)
        
    def forward(self, input, hidden):
        """ The forward function of the Vanilla RNN
            Args:
                input (tensor): a batch of data of shape (batch_size, input_size) at one time step
                hidden (tensor): the hidden value of previous time step of shape (batch_size, hidden_size)

            Returns:
                output (tensor): the output tensor of shape (batch_size, output_size)
                hidden (tensor): the hidden value of current time step of shape (batch_size, hidden_size)
        """
        #x1 = torch.cat((input, hidden), dim = 1)
        
        output, hidden = self.l1(input, hidden)
        output = self.l2(output)
        output = self.l3(output)
        return output, hidden