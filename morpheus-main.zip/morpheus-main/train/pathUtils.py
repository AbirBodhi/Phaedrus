#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 18 10:04:51 2024

@author: bodhisatwa
"""
logRoot = "/home/bodhi/Research_Repos/morpheus/train/compLogs/"
modelPath = "/home/bodhi/Research_Repos/morpheus/train/trainedModels/"
#rawDataRoot = "/home/bodhi/Research_Repos/wpp_compress/raw_data/"

#raw data should only be needed for testing the uncompressed data
rawDataRoot = "/home/bodhi/Research_Repos/morpheus/compression/raw_data"

#compressed data should have unaugmented and augmented version 
#(also has the raw version for one benchmark)
compDataRoot = "/home/bodhi/Research_Repos/morpheus/train/compLogs/"

#This helps in setting the vector-size for one hot encodings
maxTokens = dict({"519.lbm_r": 46, "525.x264_r": 684, "557.xz_r": 425, "500.perlbench_r": 2564, "505.mcf_r": 69, "508.namd_r":164, "544.nab_r": 426, "531.deepsjeng_r":190, "538.imagick_r": 2303, "520.omnetpp_r": 6522, "523.xalancbmk_r":14959, "510.parest_r": 17984, "541.leela_r": 426, "526.blender_r": 37930})
