#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 20 01:16:45 2024

@author: bodhisatwa
"""
import train
import models
import pathUtils
import torch
import torch.nn as nn
import torch.optim as optim
# Tqdm progress bar
from tqdm import tqdm_notebook
import time
import numpy as np

if __name__ == "__main__":
    device = train.getDevice()
    hidden_size = 1000
    dropout = 0.2
    learning_rate = 1e-3
    EPOCHS = 20 
    BATCH_SIZE = 64
    train.setHyperParams(hidden_size, dropout, learning_rate, EPOCHS, BATCH_SIZE)

    #benchmarks = ["500.perlbench_r", , , "510.parest_r", "511.povray_r", "519.lbm_r",  ]
    #"538.imagick_r"
    #"505.mcf_r", "508.namd_r", "525.x264_r", "531.deepsjeng_r", "541.leela_r", "544.nab_r", "557.xz_r"
    #"526.blender_r"

    benchmarks = ["557.xz_r"]

    size = ["small", "medium", "large"] 
    for bench in benchmarks:        
        start = time.time() 
        train_loader, valid_loader, test_loader, inputSize = train.getDataLoaders(bench, size, "unaugmented")  
        end = time.time()
        print("Data Construction Time: ", end - start)
        print("Train = ", len(train_loader), "Val = ", len(valid_loader), "Test = ", len(test_loader)) 
        
        #declaring the rnn model
        rnn_model, optimizer, scheduler, criterion = train.getModel()
      
        #start the training process 
        start = time.time()
        trained_model = train.startTraining(device, rnn_model, optimizer, scheduler, criterion, train_loader)
        end = time.time()
        print("Training Time: ", end - start)
        train_loss, train_loss, preds1, actual1 = train.evaluate(trained_model, train_loader, criterion, device=device, p = True)
        test2_loss, test2_loss, preds2, actual2 = train.evaluate(trained_model, valid_loader, criterion, device=device, p = True)
        train3_loss, train3_loss, preds3, actual3 = train.evaluate(trained_model, test_loader, criterion, device=device, p = True)
     
        #modelPath = pathUtils.modelPath + bench + ".model"
        #torch.save(trained_model.state_dict(), modelPath)     
