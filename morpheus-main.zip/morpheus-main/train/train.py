#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 18 15:50:51 2024

@author: bodhisatwa
"""

import prepareData
import pathUtils
import models

import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.nn.utils.rnn import pad_sequence

# Tqdm progress bar
from tqdm import tqdm_notebook

import numpy as np


#hyper-params
hidden_size = None
dropout = None
learning_rate = None 
EPOCHS = None
BATCH_SIZE = None
inputSize = None


def getDevice():
    """
    Return CPU/GPU
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    return device


def train(model, dataloader, optimizer, criterion, scheduler=None, device='cpu'):
    model.train()

    # Record total loss
    total_loss = 0.

    # Get the progress bar for later modification
    progress_bar = tqdm_notebook(dataloader, ascii=True)
    
    hidden = None
    # Mini-batch training
    for batch_idx, data in enumerate(progress_bar):
        #source = data[0].transpose(1, 0).to(device)
        #target = data[1].transpose(1, 0).to(device)
        source = data[0].to(device) 
        target = data[1].to(device)
        
        if hidden == None:        
           hidden = torch.zeros(1, source.shape[0], hidden_size)

        #print("hidden shape = ", hidden.shape, "target shape = ", target.shape)
        translation, hidden = model(source, hidden)
        
        #print(translation.shape)
        hidden.detach_()
        #translation = translation.reshape(-1, translation.shape[-1])
        #target = target.reshape(-1)

        optimizer.zero_grad()
        loss = criterion(translation, target)
        loss.backward(retain_graph = True)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
        optimizer.step()

        total_loss += loss.item()
        #print("total loss ",  total_loss)
        progress_bar.set_description_str(
            "Batch: %d, Loss: %.4f" % ((batch_idx + 1), loss.item()))

    return total_loss, total_loss / len(dataloader)


def evaluate(model, dataloader, criterion, device='cpu', p = False):
    #store the predictions & the matches
    correct_preds, total_preds = 0, 0
    preds, actual = list(), list()
    # Set the model to eval mode to avoid weights update
    model.eval()
    total_loss = 0.
    hidden = None
    with torch.no_grad():
        # Get the progress bar
        progress_bar = tqdm_notebook(dataloader, ascii=True)
        for batch_idx, data in enumerate(progress_bar):
            source = data[0].to(device)
            target = data[1].to(device)
            
            if hidden == None:        
                hidden = torch.zeros(1, source.shape[0], hidden_size)
  
            translation, hidden  = model(source, hidden)
            hidden.detach_()
            B, _, _ = translation.shape
            #print(out.shape)
            
            if p:
                for i in range(B):
                    total_preds += 1
                    if torch.equal(torch.argmax(translation[i][0][:]), torch.argmax(target[i][0][:])):
                        correct_preds += 1
                    preds.append(torch.argmax(translation[i][0][:]).item())
                    actual.append(torch.argmax(target[i][0][:]).item())
                    print(torch.argmax(translation[i][0][:]).item(), "=?", torch.argmax(target[i][0][:]).item())
                    
            
            #translation = translation.reshape(-1, translation.shape[-1])
            #target = target.reshape(-1)

            loss = criterion(translation, target)
            total_loss += loss.item()
            progress_bar.set_description_str(
                "Batch: %d, Loss: %.4f" % ((batch_idx + 1), loss.item()))

    avg_loss = total_loss / len(dataloader)
    if p:
        #print("preds = ", preds, "actual = ", actual)
        print("Correct = ", correct_preds, "total = ", total_preds, "Accuracy:", (correct_preds/total_preds) * 100)
    return total_loss, avg_loss, preds, actual

def setHyperParams(h_size, dr, l_r, E, B_S):
    """
    setting the values of hyperparams
    """
    global hidden_size, dropout, learning_rate, EPOCHS, BATCH_SIZE
    hidden_size = h_size
    dropout = dr
    learning_rate = l_r
    EPOCHS = E
    BATCH_SIZE = B_S
    
def generateBatch(data):
    """
    """
    #FIXME: needs to return tensors
    #print(len(data))
    x_batch, y_batch = list(), list()
    for (x, y) in data:
        x_batch.append(x)
        y_batch.append(y)
    
    x_batch = pad_sequence(x_batch)
    y_batch = pad_sequence(y_batch)    
    two= pad_sequence([x_batch, y_batch])
    x_batch = two[:,0,]
    y_batch = two[:,1,]
    return x_batch, y_batch    
    
def getDataLoaders(bench, size, nature):
    """
    Returns the train, test and valid loader
    """
    train_data, test_data, val_data = None, None, None
    for s in size:
        print(bench, s)
        #get the compressed logs & tokenize 
        fileName = pathUtils.logRoot + nature + "/" + bench + "/" + bench + "_" + s + ".txt"
        compTokens = prepareData.openLogs(fileName)
        
        #FIXME: according to sizes (double check)
        #augment the tokens with unseen paths
        if s == "small":
            #print("size = ", size)
            augTokens = prepareData.generateAugmentedProfile(bench)
            print(len(augTokens), "tokens to be augmented")
            compTokens += augTokens
        
        #this is for training with the raw data
        #fileName = pathUtils.rawDataRoot + bench + "/" + bench + "_wppCG_" + s + ".data"
        #compTokens = prepareData.openUncompressed(fileName)
        
        #print(compTokens)
        #convert the tokens into tensors
        compTensors = prepareData.tokensToTensor(compTokens, pathUtils.maxTokens[bench])
        #print(compTensors.shape)
           
        #set the input size
        global inputSize
        inputSize = compTensors.shape[-1]
        #convert the data into X (source) and Y (target)
        data = prepareData.prepareData(compTensors)
        
        if s == "small":
           train_data = data
        elif s == "medium":
           val_data = data
        else:
           test_data = data 
         
    train_loader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=False, collate_fn=generateBatch)
    valid_loader = DataLoader(val_data, batch_size=1, shuffle=False, collate_fn=generateBatch)    
    test_loader = DataLoader(test_data, batch_size=1, shuffle=False, collate_fn=generateBatch)
    
    return train_loader, valid_loader, test_loader, inputSize
    

def getModel():
    """
    return the RNN model along with optimizer, scheduler and 
    criterion
    """
    print("Input Size = ", inputSize, "Hidden Size = ", hidden_size, "Learning Rate = ", learning_rate)
    rnn = models.VanillaRNN(inputSize, hidden_size, inputSize)
    optimizer = optim.Adam(rnn.parameters(), lr = learning_rate)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer)
    #criterion = nn.CrossEntropyLoss()
    criterion = nn.MSELoss()
    return rnn, optimizer, scheduler, criterion

def startTraining(device, rnn_model, optimizer, scheduler, criterion, train_loader):
    """
    Starts the training process
    """
    for epoch_idx in range(EPOCHS):
      print("-----------------------------------")
      print("Epoch %d" % (epoch_idx+1))
      print("-----------------------------------")
      train_loss, avg_train_loss = train(rnn_model, train_loader, optimizer, criterion, device=device)
      scheduler.step(train_loss)

      #print("Training Loss: %.4f." % (avg_train_loss))
      val_loss, avg_val_loss, _, _ = evaluate(rnn_model, train_loader, criterion, device=device, p = False)

      print("Training Loss: %.4f. Validation Loss: %.4f. " % (avg_train_loss, avg_val_loss))
      print("Training Perplexity: %.4f. Validation Perplexity: %.4f. " % (np.exp(avg_train_loss), np.exp(avg_val_loss)))
    
    #print("Avg loss", avg_val_loss)
    #val_loss, avg_val_loss, preds, actual = evaluate(rnn_model, train_loader, criterion, device=device, p = True)
    return rnn_model



#if __name__ == "__main__":
#   for bench in benchmarks:
#       for s in size:
#           print(bench, s)
#           #get the compressed logs & tokenize 
#           fileName = pathUtils.logRoot + "unaugmented/" + bench + "/" + bench + "_" + s + ".txt"
#           compTokens = prepareData.openLogs(fileName)
#           #print(compTokens)
#           #convert the tokens into tensors
#           compTensors = prepareData.tokensToTensor(compTokens)
#           #print(compTensors.shape)
#           
#           #convert the data into X (source) and Y (target)
#           data = prepareData.prepareData(compTensors)
#           #print(len(data))
#           
#           
           
           
           
           
