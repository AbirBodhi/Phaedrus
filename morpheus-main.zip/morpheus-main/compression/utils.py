#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  7 20:23:49 2024

@author: bodhisatwa
""" 
import os, subprocess, collections, re
#head -c 50 file
#tail -c +2 infile > outfile
from pathUtils import fileChunkingRoot
fileChunkPath = fileChunkingRoot + "writeFile.sh"

def readFile(fileName):
    """
    Reads the contents of file and dumps it into a fileBuffer line-by-line
    """
    fileBuffer = list()
    fp = open(fileName, "r")
    for line in fp:
        fileBuffer.append(line)
    return fileBuffer

def process(fileName, maxSize = 300000, chunkSize = 200000000):
    """
    Tokenizes the file as a whole if size is less than maxSize,
    otherwise breaks it down into smaller pieces (chunks) & tokenizes
    
    The second return parameter tells if the file is complete or not
    """
    size = os.path.getsize(fileName)/1024
    if size < maxSize:
        return removeSingleContiguousRepetitions(tokenize(fileName))
    
    #dump this repeatedly in a file/string
    out_tokens = list()
    getFilePiece(fileName, chunkSize)
    size = os.path.getsize(fileName)/1024
    while size >= maxSize:
        print("current size: ", size)
        out_tokens += getFilePiece(fileName, chunkSize)
        size = os.path.getsize(fileName)/1024
    
    out_tokens += tokenize(fileName)
    #do a clean-up of tokens to make sure it's all numerics
    return cleanupTokens(removeSingleContiguousRepetitions(out_tokens))

def cleanupTokens(tokens):
    """
    Removes the non-numeric characters from the tokens list
    """
    for i in range(len(tokens)):
        try:
            int(tokens[i])
        except ValueError:
            tokens[i] = re.sub(r"\D", "", tokens[i])
    return tokens        
            
def getFilePiece(fileName, chunkSize):
    """
    Get complete pieces of files that are atleast chunk sized
    Also, truncates the file by that much character
    """
    
    out = str(subprocess.check_output(["head", "-c", str(chunkSize), fileName]))[2:]
    
    #Repeatedly dumping until a token is ended
    while out[-2] == ",":
        chunkSize += 1
        out = str(subprocess.check_output(["head", "-c", str(chunkSize), fileName]))[2:]
    out_tokens = out.split(",")
    
    newFileName = fileName[:-5] + "_buffer.data"
    subprocess.run(["bash", fileChunkPath, str(chunkSize), fileName, newFileName])
    return removeSingleContiguousRepetitions(out_tokens)
    
def removeSingleContiguousRepetitions(tokens):
    """
    Replaces the single tokens that repeat contiguously
    """
    if not tokens:
       return tokens
    newTokens = list([tokens[0]])
    for i in range(1, len(tokens)):
        if newTokens[-1] == tokens[i]:
            continue
        else:
            newTokens.append(tokens[i])
    return newTokens        

def maxFreqToken(tokens):
    """
    #a. construct the hashmap with tokens and their freqs
    #b. take the max freq token(iterate through the hashmap)
    """    
    funcDist = collections.Counter(tokens)
    maxFreq, maxToken = -1, None
    for token, freq in funcDist.items():
        if freq > maxFreq:
            maxFreq = freq
            maxToken = token
            
    return maxToken, funcDist        

def getCandidateString(tokens, maxToken, tokenDist, maxLen = 3):
    """
    Uses Strategy 1 to generate a candidate string for replacement 
    """    
    candStr = list([maxToken])
    start = False
    maxFreq = tokenDist[maxToken]
    seenDict = dict({maxToken:1})
    for i in range(len(tokens)):
        if not start and tokens[i] == maxToken:
            start = True
        elif start:
            #check if same token was seen before
            if tokens[i] in seenDict:
                return candStr
            seenDict[tokens[i]] = 1
            
            #check if the token is long enough
            if tokenDist[tokens[i]] > maxFreq//2:
                candStr.append(tokens[i])
            else:
                return candStr
            
            #check if candidate string is longer than maxLen
            if len(candStr) >= maxLen:
                return candStr
    return candStr

def strategyOne(tokens, maxToken, tokenDist, maxLen):
    """
    #Strategy 1 (Candidate Replacement)   
    # The idea is to first construct the most frequent substrings by
    # piecing together most frequent tokens
        #c. Initialize pointer to the first instance of max freq token
        #d. crawl until  
            #i. min(parameter maxlen, until tokens are not very frequent, same token encountered)
            # next repeat token (not used)
    #e. replace that hot string across the board    

    Driver function for strategy 1; 
    returns shortened tokens and success/failure
    
    maxToken = token with highest frequency
    tokenDist = hashmap of tokens with their frequency
    maxLen = upper-limit of hot string to be removed
    """
    repStr = getCandidateString(tokens, maxToken, tokenDist, maxLen)
    #fallback to second strategy
    if len(repStr) < 2:
        return tokens, False 
    print("hot string", repStr)
    #TODO: replace duplicate instances of repStr in tokens
    trimTokens = subArrayDeletion(tokens, repStr)
    return trimTokens, True    
                
def strategyTwo(tokens, tokenDist):
    """
    #Strategy 2 (Top-K replacement)
    #Remove the most frequent tokens ony by one     
        #c. just remove the top-k tokens
    
    Driver function for strategy 2
    returns shortened tokens
    tokenDist = hashmap of tokens with their frequency
    k = amount of hot-tokens to be removed
    """
    sortedTokenDist = {key:val for key, val in sorted(tokenDist.items(), key = lambda item: item[1], reverse = True)}
    
    #figure out k
    k = determineK(sortedTokenDist, len(tokens)) 
    #call the removal logic k times
    vals = list(sortedTokenDist.keys())[:k+1]
    print("strategy two")
    while vals:
        x = vals.pop(0)
        #print("before", len(tokens))
        tokens = subArrayDeletion(tokens, list([x]))
        #print("after", len(tokens))
        
    return tokens

def determineK(tokenDict, totalTokens):
    """
    Determine the number of tokens that account for y% of the distribution
    y = 2 * uniqueTokens/total_tokens
    """
    funcs = list(tokenDict.keys())
    perc = 100 - len(funcs)/totalTokens
    perc = min(99.999, perc)    
    limit = int(totalTokens * perc)
    k, sumT = 0, 0
    while sumT < limit and k < len(funcs):
        sumT += int(funcs[k])    
        k += 1
    print("Uniqueness Percentage: ", 100 - perc, " k = ", k)
    if k == len(funcs):
        return k - 1
    return k  

def subArrayDeletion(mainArray, subArray):
    """
    Remove instances of the subArray in mainArray 
    Keeps the first instance
    """  
    trimArray = list()
    i = 0
    start = False
    while i < len(mainArray) - len(subArray):
        #keep the first instance
        if not start and mainArray[i : i + len(subArray)] == subArray:
           start = True
           trimArray += subArray
           i += len(subArray)   
        elif mainArray[i : i + len(subArray)] == subArray:    
           i += len(subArray)           
        else:
           trimArray.append(mainArray[i])
           i += 1
    return trimArray

def removeInputDependentTokens(tokens):
    """
    #Two different strategies to replace the input-dependent repetitions 
    #Each strategy may be repeated certain number of times to achieve desireable result    
    """
    maxToken, tokenDist = maxFreqToken(tokens)
    #try stategy one, if it fails or takes too much time, go for two
    #reducedTokens, flag = strategyOne(tokens, maxToken, tokenDist, 3)
    #if flag:
    #    print("before strategy 1:", len(tokens), "after: ", len(reducedTokens))
    #    reducedTokens = strategyTwo(reducedTokens, tokenDist)
    #    print("after strategy 2: ", len(reducedTokens)) 
    #else:
    print("stategy1 not applied")
    reducedTokens = strategyTwo(tokens, tokenDist)
    print("before strategy 2:", len(tokens), "after: ", len(reducedTokens))
    
    return reducedTokens    
        
def tokenize(filename):
    """
    This function splits the comma seperated traces into individual tokens
    """
    fp = open(filename, "r")
    tokens = None
    for line in fp:
        tokens = line.split(",")
    #print(tokens)    
    return tokens[:-1]
