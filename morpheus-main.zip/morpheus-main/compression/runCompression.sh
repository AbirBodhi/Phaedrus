echo "Compressing the Raw Data & Constructing Data"

#declare -a ben=( 505.mcf_r  508.namd_r  519.lbm_r  525.x264_r  531.deepsjeng_r  541.leela_r  544.nab_r  557.xz_r )
#declare -a ben=( 510.parest_r 520.omnetpp_r 523.xalancbmk_r  )
#500.perlbench_r 538.imagick_r
declare -a ben=( 538.imagick_r )
#
# 
declare -a ben1=( small )

for i in "${ben[@]}"                                                            
do         
   echo $i                          
   for j in "${ben1[@]}"                                                            
   do
      echo $j                                                                       
      time python3 dataCompress.py $i $j
   done        
done
