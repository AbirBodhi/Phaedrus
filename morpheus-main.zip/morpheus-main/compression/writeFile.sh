#!/bin/bash                                                                     
set -euox pipefail                                                              
                                                                                
function usage_exit() {                                                         
    echo                                                                        
    echo "Usage: ./writeFile.sh chunkSize fileName"                                                                   
    exit 1                                                                      
}                                                                               

#subprocess.run(["tail", "-c", "+" + str(chunkSize), fileName, ">>", fileName])

if [ $# != 3 ]; then                                                            
    usage_exit                                                                  
fi                                                                              
                                                                                                                                                          
SIZE=$1                                                                          
INFILE=$2                                                                        
OUTFILE=$3

tail -c +${SIZE} ${INFILE} > ${OUTFILE}
rm ${INFILE}
mv ${OUTFILE} ${INFILE}  
