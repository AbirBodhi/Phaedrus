#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  7 10:04:49 2024
This file has all the PATHs 
@author: bodhisatwa
"""

staticAnalysisRoot = "/home/bodhi/Research_Repos/morpheus/compression/StaticData/"
#rawDataRoot = "/storage/home/hcoda1/2/bchatterjee8/p-sp143-0/squeezeIT/raw_data/"

rawDataRoot = "/home/bodhi/Research_Repos/morpheus/compression/raw_data/smartloopPrint"
#augDataRoot = ""

fileChunkingRoot = "/storage/home/hcoda1/2/bchatterjee8/p-sp143-0/squeezeIT/"

writeFileRoot = "/home/bodhi/Research_Repos/morpheus/compression/write_data/"

#writeFileRoot = "/storage/home/hcoda1/2/bchatterjee8/p-sp143-0/squeezeIT/write_data/"
#benchmarks = ["500.perlbench_r", "505.mcf_r", "508.namd_r", "510.parest_r", "511.povray_r", "519.lbm_r", "525.x264_r", "531.deepsjeng_r"]
