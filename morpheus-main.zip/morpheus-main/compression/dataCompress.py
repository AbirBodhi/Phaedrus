#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  7 00:31:12 2024
This compresses the raw CG traces, and returns compressed, encoded traces
@author: bodhisatwa
"""

import pathUtils, utils, sys
rootPath = pathUtils.rawDataRoot
from staticAnalysis import generateEncodedPath

#benchmarks = ["500.perlbench_r", "505.mcf_r", "508.namd_r", "510.parest_r", "511.povray_r", "519.lbm_r", "525.x264_r", "531.deepsjeng_r"]
#benchmarks = ["500.perlbench_r"]
#size = ["large"]

#size = ["small"]

#open the raw data (probably need the file path) & squeeze it with static analysis result


#maximal word match (alternate: just go over the longest path first and check matches)
def compress(encodedPaths, tokens):
    """
    Search for each encoded path in the tokens, and replace
    them with their encodings
    """
    paths = list(encodedPaths.keys())
    paths = sorted(paths, key = lambda x: len(x), reverse = True)
    #for each encoded path, compress it with the code
    for path in paths:
        tPath = path.split("-") 
        tokens = subArrayMatch(tokens, tPath, encodedPaths[path])
        #print("tokens: ", tokens)
    return tokens   
        
def subArrayMatch(mainArray, subArray, code):
    """
    Return the compressed tokens encoded with code 
    """  
    compressedArray = list()
    i = 0
    #print("searching for", subArray)
    while i <= len(mainArray) - len(subArray):
        if mainArray[i : i + len(subArray)] == subArray:
           compressedArray.append(code)
           i += len(subArray)
        else:
            compressedArray.append(mainArray[i])
            i += 1
    
    # Append any remaining elements (if subArray is near the end)
    while i < len(mainArray):
        compressedArray.append(mainArray[i])
        i += 1        
    return compressedArray    

def writeTokens(tokens, bmark):
    """
    puts the tokens in a file
    """
    fileName = pathUtils.writeFileRoot + bmark + ".txt"
    fp = open(fileName, "w")
    for t in tokens:
        fp.write(str(t))
        fp.write("\n")
    fp.close()

    

if __name__ == "__main__":
    #for bench in benchmarks:
        #getting the benchmark and size from cmd line args
        sysArgs = sys.argv
        bench = sysArgs[-2]
        s = sysArgs[-1]

        #get the static analysis compression dictionary
        encodedPaths = generateEncodedPath(bench)
        print("path encodings: ", encodedPaths)
        #print("Total Encoded Paths Found:", len(encodedPaths))
        #totalSum = 0
        #for path, id in encodedPaths.items():
        #    totalSum += len(path.split("-"))
        #print("Average Path Length: ", totalSum/len(encodedPaths))

        #encodedPaths = adjustPathCodes(Fmap, encodedPaths)
        
        #print(encodedPaths)
        print(bench, s)

        fileName = rootPath + "/" + bench + "/" + bench + "_wppCG_" + s + ".data"
        fileTokens = utils.tokenize(fileName)
        print(len(fileTokens))
        #print(fileTokens, len(fileTokens))
        #change path codes
    
        print("performing input-consistent compression")
        compressedTokens = compress(encodedPaths, fileTokens)
        print("after compression: ", len(compressedTokens))
        #print("after compression: ", len(compressedTokens), compressedTokens)
                      
        #write the tokens
        bname = bench + "_" + s
        writeTokens(compressedTokens, bname)
