#include<cstdio>
#include<fstream>
#include<stdint.h>
#include<stdarg.h>
#include<string>
#include <iostream>
#include<utility>
#include <cstring>
  
#include <vector>
#include <map>
#include <set>

#define LIMIT 1000000
using namespace std;


//path counter
int pathCounter = 0, compPathCounter = 0;

//Map func ids to their set unique basic blocks 
map <int, set <int>> functoUniqueBBs;

//encodes FuncID-BB into a number
map <string, int> pathDict;

//encodes composite paths to a number
map <string, int> compPathDict;

//vector to store entire path
vector <pair<int, int>> megaPath;

//string to store the current active path
string activePath = "";

map<int, map<int, int>> loopToBranchBitMask;
map<int, map<int, int>> loopToBranchFreq;
map<int, std::ofstream> mappedfiles;
map<int, bool> writeFile;

static std::ofstream f_path;
std::ofstream ue_path;

//put the path in the mega stream
extern "C" void capturePath(int P) {

   // put the encoded commposite path in the stream vector
   //check the last element of vector
   //if it's same increment its frequency

    if (megaPath.empty()) {
        megaPath.push_back(pair<int, int>(P, 1));
    }
    
    else {
        int n = megaPath.size();
        //if it matches increment the frequency 
        if (megaPath[n - 1].first == P) { 
           megaPath[n - 1].second += 1;
        }
        else {
            megaPath.push_back(pair<int, int>(P, 1));
        }
    }
}

//return the composite path code
//see if the path is present in a dictionary and get the code
//otherwise put it in a dict and encode it
extern "C" int getCompPathCode(string S){
    
    if(compPathDict.find(S) == compPathDict.end()) {
        compPathDict[S] = compPathCounter;
        compPathCounter += 1;
    }
    return compPathDict[activePath];
}

extern "C" void instLib_init(char *file) {

   cout << "Start Inst\n";
   f_path.open(file, std::ios::out | std::ios::app);
}

extern "C" void printMegaPath(){

   //check is file is open or not
   if (!f_path.is_open()) {
       f_path.open("wpp_data.prof", std::ios::out | std::ios::app);
   }

   for (auto it = megaPath.begin(); it != megaPath.end(); ++it) {
      //pair <int, int> x = *it;  
      f_path << it->first << "#" << it->second  << ",";
   }
   cout << "\n";
}

extern "C" void printKeys() {

   for (auto it = functoUniqueBBs.begin(); it != functoUniqueBBs.end(); ++it) {
      cout << "Func: " << it->first << " with " << it->second.size() << " unique blocks" << "\n";
   }

   for (auto it = pathDict.begin(); it != pathDict.end(); ++it) {
      cout << "path: " << it->first << " with ID = " << it->second  << "\n";
   }

   for (auto it = compPathDict.begin(); it != compPathDict.end(); ++it) {
      cout << "Composite Path: " << it->first << " with ID = " << it->second  << "\n";
   }
 
}

extern "C" void instLib_fini() {
   
   cout << "Finish Inst\n";
   //put the last active path
   if (!activePath.empty()) {
    int compPathCode = getCompPathCode(activePath);
    capturePath(compPathCode);
   }
   
   //print out the data structures for reference
   printKeys();

   //write the profile to a file
   printMegaPath();
   f_path.close();
}

//see if string S contains ch 
//path is not broken until repeated block comes up
extern "C" bool checkBrokenPath(string S, int chN) {
    
    //cout << "Checking for " << chN << " in " << S << "\n"; 
    char x = '-';
    string ch = to_string(chN);
    int p1 = 0, p2 = 0;
    while (true) {
        //cout << "p1 = " << p1 << " p2 = " << p2 << "\n";
        //cout << "S[p1] = " << S[p1] << " S[p2] = " << S[p2] << "\n";
        while(p2 < S.size() && S[p2] != x) {
            p2 += 1;
        }
        if (p2 == S.size()) {
            break;
        }
        string S1 = string(&S[p1], &S[p2]);
        if (S1 == ch) {
            return true;  
        }
        p1 = p2 + 1;
        p2 = p1;
    }
    return false;
}

extern "C" void instLib_bb_info(uint64_t funcID, uint64_t loopID, uint64_t bbID) {
    
    //cout << "funcID" << funcID << "\n";
    size_t it = functoUniqueBBs.count(funcID);
    if (it == 0) {
        set <int> tempBBs;
        //tempBBs.insert(bbID);
        functoUniqueBBs[funcID] = tempBBs;
    }
    functoUniqueBBs[funcID].insert(bbID);
    
    //1. generate the path string
    string s1 = to_string(funcID) + "_" + to_string(bbID); 
    //cout << s1 << "\n";
    
    //2. put the path string in the dictionary (if it's not there) & get the pathcode
    if (pathDict.find(s1) == pathDict.end()) {
        pathCounter += 1;
        pathDict[s1] = pathCounter;        
    }
    int pCode = pathDict[s1];
    //cout << "pCode = " << pCode << "\n"; 
    //cout << "activePath = " << activePath << "\n";

    //3. Get the active path in the stream 
    //we can get the active path from a counter variable
    
    if (activePath.empty()) {
        activePath = to_string(pCode);
    }  
    else {
        //checking for broken path
        if (!checkBrokenPath(activePath, pCode)){
            //add the character to active path
            activePath +=  "-" + to_string(pCode);
        }
        else {
            //path is broken
            int compPathCode = getCompPathCode(activePath);
            //re-initialize the active path with the broken bit
            activePath = to_string(pCode);

            //4. encode the path in the stream
            capturePath(compPathCode);
            //printMegaPath();
        }
    }

    if (megaPath.size() > LIMIT) {
        printMegaPath();
        //clear off all but last
        int n = megaPath.size();
        pair <int, int> temp = megaPath[n - 1];
        megaPath.clear();
        megaPath.push_back(temp);
    }
    
    //1. Create a dictionary that maps paths to thier IDs
    //idea 1: map of func+bbs to ID & replace string with ID
              //add a counter after ID to compress shorter path
            
    //idea 2: keep active path counter & check with seen paths          
}


/*
extern "C" void instLib_activate_branch(uint64_t branchID, uint64_t loopID) {

    auto it = loopToBranchBitMask.find(loopID);
    if (it == loopToBranchBitMask.end()) {
        map <int, int> tempBranchBitMask;
        tempBranchBitMask[branchID] = 0;
        loopToBranchBitMask[loopID] = tempBranchBitMask;
        //branchBitMask[{branchID, LoopID}] = 0;
    }
    loopToBranchBitMask[loopID][branchID] = 1;
    //cout << "size of loop to branchbitmask : " << loopToBranchBitMask.size() << "\n";
}

extern "C" void instLib_print_info(char* function) {
    string stringfile(function);

    //if (!looptoBranchTC.size()) {
    //     return;
    //}


    //cout << "Printing Branch Frequecies: "<< stringfile << "\n";
     for (auto it = branchToFreq.begin(); it != branchToFreq.end(); ++it) {
         auto branchFreq = it->second;
        //Todo uncomment the file one
        //cout << stringfile << " branchID:" << it->first << " taken:" << branchFreq[0] << " NotTaken:" << branchFreq[1] << flush << "\n";  
        f_path << stringfile << " " << it->first << " " << branchFreq[0] << " " << branchFreq[1] << "\n"; 
        //f_path << "Function : " << stringfile << " Branch ID : " << it->first << " with outcome : " << takenID << "\n";   
      }
    //COmmented out for Backslicing
    //f_path << "Printing Loop Stats\n";
    //cout << "Printing Loop Stats\n";

    float avgTc = 0.0;
    for (auto it : looptoBranchTC) {
        //f_path << "Loop ID : " << it.first << "\n";
        //cout << "LoopID :" << it.first << "\n";
        for (auto branchIDit : it.second) {
            if (loopToBranchFreq[it.first][branchIDit.first]) {
                avgTc = branchIDit.second/loopToBranchFreq[it.first][branchIDit.first];
            }  
           if (avgTc) {
              f_path << "  LoopID: " << it.first <<  " Branch: " << branchIDit.first <<  " Avg TripCount: " << avgTc << "\n";
           } 
           //cout << "  LoopID: " << it.first <<  " Branch: " << branchIDit.first <<  " Avg TripCount: " << avgTc << "\n";
        }
    } 
 
    float avgTc = 0.0;
    for (auto it : looptoBranchTC) {
        std::string stringfile(std::to_string(it.first)+".var");
        if(mappedfiles.count(it.first) != 0 && writeFile[it.first])
        {   
            for (auto branchIDit : it.second) {
                if (loopToBranchFreq[it.first][branchIDit.first]) {
                    avgTc = branchIDit.second/loopToBranchFreq[it.first][branchIDit.first];
                }
                if (avgTc) { 
                   mappedfiles[it.first] << "LoopID: " << it.first  << " Branch: " << branchIDit.first  << " Average TripCount: " << avgTc << std::flush;  
                }              
            }
            writeFile[it.first] = false;
        }
    
}

extern "C" void instLib_uint_64(uint64_t value, char *file) {
    std::string stringfile(file);
    f_path << stringfile << " : " << value << "\n";
}

//Keep track of branch outcomes for counting frequencies
extern "C" void instLib_count_branch_freq(uint64_t branchID, uint64_t takenID, char *file) {
   //cout << "branch ID = " << branchID << " & outcome : " << takenID << "\n";
   //cout << "----\n";
   //if branch ID is not in map, initialize it in the map
    if(branchToFreq.count(branchID) == 0 || branchToFreq[branchID].count(takenID) == 0) {
        branchToFreq[branchID][takenID] = 0;           
    }
    branchToFreq[branchID][takenID] += 1;
    if (takenID == 0) {
        branchToFreq[branchID][1] -= 1;
    }
}

//Initialize/Increment local loop trip count
extern "C" void instLib_inc_trip_count(uint64_t loopID) {
    //cout << "Starting/Inc Loop Counter \n";
    if (loopToTripCount.count(loopID) == 0) {
        loopToTripCount[loopID] = 0;
    }
    loopToTripCount[loopID] += 1;
}

//Stop the local trip count and put it in path sensitive counter
extern "C" void instLib_stop_trip_count(uint64_t loopID) {
    auto it = loopToTripCount.find(loopID);
    if (it != loopToTripCount.end()) {
        loopToTripCount[loopID] -= 1;
        //cout << "Local Trip Count of Loop: " << loopToTripCount[loopID] << "\n";
        //put this in the path sensitive counter in branch
        auto it2 = loopToBranchBitMask.find(loopID);
        //cout << "size of loop to branchbitmask : " << loopToBranchBitMask.size() << "\n";
        
        if (it2 != loopToBranchBitMask.end()){
            map <int, int> tempBranchMap = loopToBranchBitMask[loopID];
            for (auto branchIDit: tempBranchMap) {
                int branchID = branchIDit.first;
                if (tempBranchMap[branchID]) {

                    //TODO: fix the freq counter
                    //loopToBranchFreq[loopID][branchID] += 1;
                    auto it5 = loopToBranchFreq.find(loopID);
                    if (it5 == loopToBranchFreq.end()) {
                       map <int, int> tempBranchFreqMap;
                       tempBranchFreqMap[branchID] = 1;
                       loopToBranchFreq[loopID] = tempBranchFreqMap;
                       //cout << "initializing branch freq 1\n";     
                    }       
                
                    else {
                        map <int, int> tempBranchFreqMap = loopToBranchFreq[loopID];
                        auto it6 = tempBranchFreqMap.find(branchID);
                        if (it6 == tempBranchFreqMap.end()) {
                            //cout << "initializing branch freq 2\n";
                            tempBranchFreqMap[branchID] = 1;
                            loopToBranchFreq[loopID] = tempBranchFreqMap;    
                        }
                    
                        else {
                            tempBranchFreqMap[branchID] += 1;
                            //cout << "incrementing branch freq 3\n";
                            loopToBranchFreq[loopID] = tempBranchFreqMap;
                        }
                    }
                
                     
                    auto it3 = looptoBranchTC.find(loopID); 
                    if (it3 == looptoBranchTC.end()) {
                         map <int, int> tempBranchTCMap;
                         tempBranchTCMap[branchID] = loopToTripCount[loopID];
                         looptoBranchTC[loopID] = tempBranchTCMap;
                    }
                    else {
                        map <int, int> tempBranchTCMap = looptoBranchTC[loopID];
                        auto it4 = tempBranchTCMap.find(branchID);
                        if (it4 == tempBranchTCMap.end()){
                            tempBranchTCMap[branchID] = loopToTripCount[loopID];
                            looptoBranchTC[loopID] = tempBranchTCMap;
                        }

                        else {
                            tempBranchTCMap[branchID] += loopToTripCount[loopID];
                            looptoBranchTC[loopID] = tempBranchTCMap;
                        }
                    }
                }
                loopToBranchBitMask[loopID][branchID] = 0;
            }
        }
        //deactivate that branch as well
        loopToTripCount.erase(it);
    }
}

//This is no longer used now
extern "C" void instLib_branch_inst(uint64_t branchID, uint64_t takenID, char *file) {
    std::string stringfile(file);
    f_path << "Function : " << stringfile << " Branch ID : " << branchID << " with outcome : " << takenID << "\n"; 
    
    //instLib_count_branch_freq(branchID, takenID);
}

extern "C" void instLib_backslice_int(int loopFile, int branch, uint64_t value) {
    std::string stringfile(std::to_string(loopFile)+".var");
    if(mappedfiles.count(loopFile) == 0)
    {
        mappedfiles[loopFile].open(stringfile, std::ios::out | std::ios::app);
    }
    if(looptoBranchTC[loopFile].count(branch) == 0)
    {
        looptoBranchTC[loopFile][branch] = 0;
    }
    mappedfiles[loopFile] << "Loop (" << loopFile  << ") Branch [" << branch << "]: " << value << "\n" << std::flush;
    writeFile[loopFile] = true;
}

extern "C" void instLib_backslice_double(int loopFile, int branch, double value) {
    std::string stringfile(std::to_string(loopFile)+".var");
    if(mappedfiles.count(loopFile) == 0)
    {
        mappedfiles[loopFile].open(stringfile, std::ios::out | std::ios::app);
    }
    if(looptoBranchTC[loopFile].count(branch) == 0)
    {
        looptoBranchTC[loopFile][branch] = 0;
    }
    mappedfiles[loopFile] << "Loop (" << loopFile  << ")/Branch [" << branch << "]: " << value << "\n" << std::flush;
    writeFile[loopFile] = true;
}
*/
