#include "llvm/Pass.h"
#include "llvm/IR/Function.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"

#include "llvm/Analysis/LoopInfo.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Dominators.h"
#include "llvm/Analysis/PostDominators.h"

#include "llvm/IR/IRBuilder.h"

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <tuple>
#include <algorithm>

using namespace llvm;
using namespace std;

namespace {
    struct getCGPass : public FunctionPass {
    static char ID;

    map <StringRef, int> fMap;
    map <int, vector <int>> CFG;
    map <int, vector <int>> isControlDep;
    int tID = 1, funcID = 0;
    
    getCGPass() : FunctionPass(ID) {}

    string moduleName;
    bool checkForbidden(string Fname);
    int postdominatorCheck(auto Branches, Instruction* I, PostDominatorTree &DI, map <Instruction*, int> brTargetIDs); 

    void getAnalysisUsage(AnalysisUsage &AU) const {
      // pass for getting the loop information
      AU.addRequired<DominatorTreeWrapperPass>();
      AU.addRequired<PostDominatorTreeWrapperPass>();
      AU.addRequired<LoopInfoWrapperPass>();   	    
      AU.setPreservesAll();
    }

    virtual bool doInitialization(Module &M) {

      moduleName = M.getName().str();
      for (auto &F: M) {
        if (F.hasName() || !F.isDeclaration()) {
          //store it in a hashmap
          fMap[F.getName()] = funcID;
          funcID++; 
        }
      }
      return false;
     }

    virtual bool runOnFunction(Function &F) {
     
      if(!F.hasName() || F.isDeclaration()) {
        return false;
      }

      errs() << "Function Name: " << F.getName() << " and ID: " << fMap[F.getName()] << "\n";
      
      int funcID = fMap[F.getName()];

      //getting the loopinfo, dominator and postdominator tree
      LoopInfo &LI = getAnalysis<LoopInfoWrapperPass>().getLoopInfo();
      DominatorTree &DI = getAnalysis<DominatorTreeWrapperPass>().getDomTree();
      PostDominatorTree &PDI = getAnalysis<PostDominatorTreeWrapperPass>().getPostDomTree();
   
      //this will be stored in CFG
      vector <int> calleeIDs;

      //this will be stored in isControlDep 
      //gives the latest branch target-ID on which call is control-dependent on
      vector <int> controlDeps; 

      //create a Data structure for branchInstructions & SwitchInstructiond
      vector <BranchInst*> branches;
      vector <SwitchInst*> switches;

      //map the branch inst targets with an ID
      map <Instruction*, int> brTargetIDs;
      int domTarget1 = 0, domTarget2 = 0, domTarget = 0;
       
      for (auto &BB: F)  {
        for (auto &I: BB) {
          //check if an instruction is a branch or function call
          if (dyn_cast<CallInst>(&I)) {
              CallInst *CI = dyn_cast<CallInst>(&I);
              Function *ce = CI->getCalledFunction();
              if(ce && ce->hasName() && !ce->isDeclaration()) {
               // errs() << "Call Instruction: " << I << "\n";
                int ceFuncId = fMap[ce->getName()];
                calleeIDs.push_back(ceFuncId);
                //errs () << "Callee ID: " << ceFuncId << "\n";
                //check for control dependence with all branches encountered till now
                //errs() << "Post Dom Check for FuncID: " << ceFuncId << "->" << postdominatorCheck(branches, &I, PDI) << "\n";
                //Case where same function call is in different branch targets will be equivalent, since we're interested in compression
                domTarget1 = postdominatorCheck(branches, &I, PDI, brTargetIDs);
                domTarget2 = postdominatorCheck(switches, &I, PDI, brTargetIDs);
                domTarget = max(domTarget1, domTarget2);
                //errs() << "Post Dom Check for FuncID: " << ceFuncId << "->" << domTarget1 << ", and switch: " << domTarget2 << "\n";
                controlDeps.push_back(domTarget);
              }
          }
          else if (dyn_cast<BranchInst>(&I)) {
            //it's fine even if it's coming from loop header
            BranchInst* BI = dyn_cast<BranchInst>(&I);
            branches.push_back(BI);
            for (int i = 0; i < BI->getNumSuccessors(); ++i) {
                BasicBlock* targetBB = BI->getSuccessor(i);
                Instruction* target = &(targetBB->front());
                brTargetIDs[target] = tID;
                tID += 1;
            }
          }
          //Considering Switch Instructions Separately
          else if (dyn_cast<SwitchInst>(&I)) {
            //it's fine even if it's coming from loop header
            SwitchInst* SI = dyn_cast<SwitchInst>(&I);
            switches.push_back(SI);
            for (int i = 0; i < SI->getNumSuccessors(); ++i) {
                BasicBlock* targetBB = SI->getSuccessor(i);
                Instruction* target = &(targetBB->front());
                brTargetIDs[target] = tID;
                tID += 1;
            }
          } 
        }
      }

      CFG[funcID] = calleeIDs;
      isControlDep[funcID] = controlDeps;

      calleeIDs.clear();
      controlDeps.clear();
      return false;
    }

    virtual bool doFinalization(Module &M) {
      errs () << "***********************\n";
      errs() << "Function Adjacency List\n";
      for (auto func : CFG) {
        errs() << func.first << ":" << "\n";
        for (auto func2 : func.second) {
          errs() << func2 << " ";
        }
        errs() << "\nControl Dependency:\n";
        for (auto cd : isControlDep[func.first]) {
            errs() << cd << " ";
        }
        assert(func.second.size() == isControlDep[func.first].size());
        errs() << "\n-------\n";
      }
      errs () << "***********************\n";
      return false;
      }
  };

  int getCGPass :: postdominatorCheck(auto B, Instruction* I, PostDominatorTree &DI, map <Instruction*, int> brTargetIDs) {
      
      //this will store the id of latest branch target on which function is control-dependent 
      int maxBTid = 0, currBTid;

      //for (auto brI : B)
      for (auto brI = B.rbegin(); brI != B.rend(); ++brI) {
        //general case: a branch can have k-targets
        int k = (*brI)->getNumSuccessors();
        //Skipping unconditional branches
        if (k == 1) {
          continue;
        }

        vector<int> bitCounter(k, 0);
        //CallInst should post dominate all targets of the branch to be control independent
        for (int i = 0; i < k; ++i) {
          BasicBlock* targetBB = (*brI)->getSuccessor(i);
          //Get the first instruction from the bb
          Instruction* target = &(targetBB->front());

          //current branch target ID
          currBTid = brTargetIDs[target];

          if (!DI.dominates(I, target)) {
            bitCounter[i] = 0;
            //errs() << " CallInst " << *I<< " does not postdominate target" << currBTid << " of branch " << **brI << "\n";
          }
          else {
            //errs() << " CallInst " << *I<< " does postdominate target" << currBTid << " of branch " << **brI << "\n";
            bitCounter[i] = 1;
            if (currBTid > maxBTid) {
              maxBTid = currBTid;
            }
          }
        }
        //XOR - all must not be the same
        int arrXor = bitCounter[0]; 
        for (int i = 1; i < k; ++i) {
             arrXor = arrXor ^ bitCounter[i];
        }
        //errs () << "arrXOR = " << arrXor << "\n";
        if (arrXor) {
          //CallInst is Control Dependent on branch brI
          //errs() << "CallInst is Control Dependent on branch brI" << **brI << "with target: " << maxBTid << "\n";
          return maxBTid;
        }
        else {
          maxBTid = 0;
        }
        
        //else {
          //CallInst is Control Dependent on branch brI
          //return the branch target ID
        //  return maxBTid; 
        //}
      }
      //CallInst is not control dependent on any branches
      return 0;
  }
}

char getCGPass::ID = 0;
static RegisterPass<getCGPass> Y("CGP", "getCGPass"); 
