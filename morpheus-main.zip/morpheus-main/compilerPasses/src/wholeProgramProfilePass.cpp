#include "llvm/Pass.h"
#include "llvm/IR/Function.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"

#include "llvm/Analysis/LoopInfo.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Dominators.h"
#include "llvm/Analysis/PostDominators.h"

#include "llvm/IR/IRBuilder.h"
#include "llvm/Analysis/TargetLibraryInfo.h"

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <tuple>
#include <algorithm>

using namespace llvm;
using namespace std;

namespace {
  struct wholeProgramProfilePass : public FunctionPass {
    static char ID;

    map <StringRef, int> fMap;
    set<string> builtins;
    wholeProgramProfilePass() : FunctionPass(ID) {}

    map <BasicBlock*, int> bbIdMap;
    map <int, int> loopBBMap;
   
    int bid = 0, branches;
    bool startAnalysis = false;

    LLVMContext* pC;
    FunctionCallee instLib_init, instLib_fini,
    instLib_bb_info; 
    //instLib_branch_inst, 
    //instLib_count_branch_freq, instLib_print_info, instLib_inc_trip_count, 
    //instLib_stop_trip_count, instLib_activate_branch, instLib_backslice_double, instLib_backslice_int;

    string moduleName;

    BasicBlock* getBlockbyID(int id);
    void instrumentInitialization(Function &F);
    void printInstrumentation(Function &F);
    void finish_inst(Function &F);
    bool checkForbidden(string Fname);


    void getAnalysisUsage(AnalysisUsage &AU) const {
      // pass for getting the loop information
      AU.addRequired<DominatorTreeWrapperPass>();
      AU.addRequired<PostDominatorTreeWrapperPass>();
      AU.addRequired<LoopInfoWrapperPass>();   	    
      AU.setPreservesAll();
    }

    virtual bool doInitialization(Module &M) {

      branches = 0;
      int funcID = 0;
      pC = &(M.getContext());
      moduleName = M.getName().str();
      IRBuilder<> IRB(*pC);

      instLib_init = M.getOrInsertFunction("instLib_init", IRB.getVoidTy(), IRB.getInt8PtrTy());
      instLib_fini = M.getOrInsertFunction("instLib_fini", IRB.getVoidTy());
      instLib_bb_info = M.getOrInsertFunction("instLib_bb_info", IRB.getVoidTy(), IRB.getInt64Ty(), IRB.getInt64Ty(), IRB.getInt64Ty());
      /*instLib_branch_inst = M.getOrInsertFunction("instLib_branch_inst", IRB.getVoidTy(), IRB.getInt64Ty(), IRB.getInt64Ty(), IRB.getInt8PtrTy());
      instLib_count_branch_freq = M.getOrInsertFunction("instLib_count_branch_freq", IRB.getVoidTy(), IRB.getInt64Ty(), IRB.getInt64Ty(), IRB.getInt8PtrTy());
      instLib_print_info = M.getOrInsertFunction("instLib_print_info", IRB.getVoidTy(), IRB.getInt8PtrTy());
      instLib_inc_trip_count = M.getOrInsertFunction("instLib_inc_trip_count", IRB.getVoidTy(), IRB.getInt64Ty());
      instLib_stop_trip_count = M.getOrInsertFunction("instLib_stop_trip_count", IRB.getVoidTy(), IRB.getInt64Ty());
      instLib_activate_branch = M.getOrInsertFunction("instLib_activate_branch", IRB.getVoidTy(), IRB.getInt64Ty(), IRB.getInt64Ty());
      instLib_backslice_double = M.getOrInsertFunction("instLib_backslice_double", IRB.getVoidTy(), IRB.getInt64Ty(), IRB.getInt64Ty(), IRB.getDoubleTy());
      instLib_backslice_int = M.getOrInsertFunction("instLib_backslice_int", IRB.getVoidTy(), IRB.getInt64Ty(), IRB.getInt64Ty(), IRB.getInt64Ty());
      //instLib_uint_64 = M.getOrInsertFunction("instLib_uint_64", IRB.getVoidTy(), IRB.getInt64Ty(), IRB.getInt8PtrTy());*/
      //errs() << "Module Name: " << moduleName << "\n";  
      
      //For detecting built-in library functions
      const TargetLibraryInfo *TLI; 
      LibFunc inbuilt_func;
     
      for (auto &F: M) {
 
         if (TLI->getLibFunc(F, inbuilt_func)){
            builtins.insert(string(F.getFunction().getName()));
            //errs() << "built-in function: " << F.getFunction().getName() << "\n";
         }


         if (F.hasName() || !F.isDeclaration()) {
             
            //store it in a hashmap
            fMap[F.getName()] = funcID;
            //if (funcID == 55) {
            //  errs() << "Forbidden Function: " << F.getName() << "\n"; 
            //}
            funcID++; 
         }
      }
      return false;
     }

    virtual bool runOnFunction(Function &F) {
     
      if(!F.hasName() || F.isDeclaration() || checkForbidden(string(F.getName()))) {
        return false;
      }
      int bbId = 0;
      errs() << "Function Name: " << F.getName() << " and ID: " << fMap[F.getName()] << "\n";
      
      //getting the loopinfo, dominator and postdominator tree
      LoopInfo &LI = getAnalysis<LoopInfoWrapperPass>().getLoopInfo();
      DominatorTree &DI = getAnalysis<DominatorTreeWrapperPass>().getDomTree();
      PostDominatorTree &PDI = getAnalysis<PostDominatorTreeWrapperPass>().getPostDomTree();
   
      for (auto &BB: F) {
          bbIdMap[&BB] = bbId;
          loopBBMap[bbId] = -1;
          bbId += 1;
      }

      int lID = 0;
      for (auto &L: LI) {
        for (auto BB = L->block_begin(); BB != L->block_end(); ++BB) { 
              //map the loop basic block with the loop id {bbID: LID}
              int bID = bbIdMap[*BB];
              loopBBMap[bID] = lID; 
        }
        lID += 1; 
      }
      BasicBlock *specialBB = NULL;
      if (F.getName() == "main") {
        //startAnalysis = true;
        //instrumenting the printing info so that it appears second
        Instruction *begin = &*(F.getEntryBlock().getFirstInsertionPt());
        IRBuilder<> IRB(begin); 
        //get the parent basic block of this inst
         specialBB = &(F.getEntryBlock()); 
        IRB.CreateCall(instLib_bb_info, {ConstantInt::get(Type::getInt64Ty(*pC), fMap[F.getName()]), ConstantInt::get(Type::getInt64Ty(*pC), loopBBMap[bbIdMap[specialBB]]), ConstantInt::get(Type::getInt64Ty(*pC), bbIdMap[specialBB])});
        instrumentInitialization(F);
      }
            
      
      for (auto &BB: F) {
         //errs() << "fID = " << fMap[F.getName()] << " lID = " << loopBBMap[bbIdMap[&BB]] << " bID = " << bbIdMap[&BB] << "\n";
         //errs() << fMap[F.getName()] << "_" << loopBBMap[bbIdMap[&BB]] << "_" << bbIdMap[&BB] << "\n";


        //TODO: Fix the seg fault in gaps
        BasicBlock* pBB = &BB;
        if (pBB == specialBB) {
          continue;
        }
        //if (startAnalysis) {
          Instruction* IBeginT = &*((&BB)->getFirstInsertionPt()); 
          IRBuilder<> IRB(IBeginT); 
          IRB.CreateCall(instLib_bb_info, {ConstantInt::get(Type::getInt64Ty(*pC), fMap[F.getName()]), ConstantInt::get(Type::getInt64Ty(*pC), loopBBMap[bbIdMap[&BB]]), ConstantInt::get(Type::getInt64Ty(*pC), bbIdMap[&BB])});
        //}
      }
      //instrument the exit block of function to print information
      //printInstrumentation(F);

      //Add the finalization after the custom instrumentation
      if (F.getName() == "main") {
        finish_inst(F);
      }
     
      bbIdMap.clear();
      loopBBMap.clear();
      return true;
    }

    virtual bool doFinalization(Module &M) {
      errs () << "***********************\n";
      errs () << "***********************\n";
      return false;
      }
  };

  bool wholeProgramProfilePass :: checkForbidden(string Fname) {
      
    if (builtins.count(Fname) != 0) {
       errs() << "found built-in" << Fname << "\n"; 
       return true;
    }

    if (Fname.find("_GLOBAL__sub") != string::npos) {
       return true;         
    }

    if (Fname.find("__cxx_global_var_init") != string::npos) {
       return true;         
    }

    if (Fname.find("__gnu_cxx") != string::npos) {
       return true;         
    }

    //forbidden funcs for 508.namd_r
    if (Fname.find("ComputeNonbondedWorkArrays") != string::npos) {
        return true;
    }

    if (Fname.find("ResizeArrayRaw") != string::npos) {             
        return true;                                                             
    } 

    //forbidden for 511.povray_r
    if (Fname.find("TextStreamBuffer") != string::npos) {
        return true;
    }

    //if (Fname.find("POVMSUtil_TempAllocPPvi") != string::npos) {                       
    //  return true;                                                             
    //}

    //if (Fname.find("XalanMemMgrs14getDummyMemMgrEv") != string::npos) {                
    //   return true;                                                             
    //}

    if (Fname.find("ExecuteOnStartup") != string::npos) {                
       return true;                                                             
    } 

    if (Fname.find("CommonStringPool") != string::npos) {                       
        return true;                                                             
    }

    if (Fname.find("cEnvir") != string::npos) {                       
       return true;                                                            
    }

    if (Fname.find("cGlobalRegistrationList") != string::npos) {
       return true;
    }

    if (Fname.find("cStringPool") != string::npos) {                
       return true;                                                             
    }
                                                     
    return false;
  }

  
  BasicBlock* wholeProgramProfilePass :: getBlockbyID(int id) {
      for (auto it = bbIdMap.begin(); it != bbIdMap.end(); ++it)
          if (it->second == id)
             return it->first;
      return NULL;
  }  

 void wholeProgramProfilePass :: instrumentInitialization(Function &F) {
      
      /* Create instLib_init function at beginning of main */
      Instruction *begin = &*(F.getEntryBlock().getFirstInsertionPt());
      IRBuilder<> IRBBegin(begin);
      //Value *file1 = IRBBegin.CreateGlobalStringPtr(StringRef(moduleName + ".prof"));
      Value *file1 = IRBBegin.CreateGlobalStringPtr(StringRef("wpp_data.prof")); 
      
      IRBBegin.CreateCall(instLib_init, {file1});
 }

  void wholeProgramProfilePass :: finish_inst(Function &F) {

      /* Create instLib_fini function at each Exit block */
      //startAnalysis = false;
      vector<Instruction*> ExitBlocks;
      for (BasicBlock &B : F) {
        if (isa<ReturnInst>(B.getTerminator())) {
            ExitBlocks.push_back(B.getTerminator());
        }
        else if(isa<UnreachableInst>(B.getTerminator())) {
            if(B.getTerminator()->getPrevNode()) {
                ExitBlocks.push_back(B.getTerminator()->getPrevNode());
            }
            else {
              ExitBlocks.push_back(B.getTerminator());
            } 
        }
      }        

      for(auto i : ExitBlocks) {
         IRBuilder<> IRBEnd(i);
          IRBEnd.CreateCall(instLib_fini, {});
      }  
  } 

	//This will instrument the function that dumps all info at the end of the function
	void  wholeProgramProfilePass :: printInstrumentation(Function &F) {

		auto FuncName = F.getName();  
		vector<Instruction*> ExitBlocks;
		for (BasicBlock &B : F) {
			if (isa<ReturnInst>(B.getTerminator())) {
				ExitBlocks.push_back(B.getTerminator());
			}
			else if(isa<UnreachableInst>(B.getTerminator())) {
				if(B.getTerminator()->getPrevNode()) {
					ExitBlocks.push_back(B.getTerminator()->getPrevNode());
				}
				else {
				ExitBlocks.push_back(B.getTerminator());
				} 
			}
		}        
			
		//for(auto i : ExitBlocks) {
		//	IRBuilder<> IRBEnd2(i);
		//	Value *line = IRBEnd2.CreateGlobalStringPtr(StringRef(FuncName));
		//	IRBEnd2.CreateCall(instLib_print_info, {line});
		//}
	}
}

char wholeProgramProfilePass::ID = 0;
static RegisterPass<wholeProgramProfilePass> Y("WPPP", "wholeProgramProfilePass"); 
/*
static void loopBranchDetectorPass(const PassManagerBuilder &,
                         legacy::PassManagerBase &PM) {
  PM.add(new wholeProgramProfilePass());
}
static RegisterStandardPasses
  RegisterMyPass(PassManagerBuilder::EP_EarlyAsPossible,
                 registerSkeletonPass);
*/
