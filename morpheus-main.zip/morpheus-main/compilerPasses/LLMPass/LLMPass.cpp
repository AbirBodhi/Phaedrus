#include "llvm/Pass.h"
#include "llvm/IR/Function.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"

#include "llvm/Analysis/LoopInfo.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Dominators.h"
#include "llvm/Analysis/PostDominators.h"

#include "llvm/IR/IRBuilder.h"

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <tuple>
#include <algorithm>

using namespace llvm;
using namespace std;

namespace {
  struct LLMPass : public FunctionPass {
    static char ID;

    map <StringRef, int> fMap;
    set<string> builtins;
    LLMPass() : FunctionPass(ID) {}
    vector <int> forbidden; 

    map <BasicBlock*, int> bbIdMap;
    map <int, int> loopBBMap;
    set <Function*> usefulFunctions; 

    int loopID;
    map <int, Loop*> loopMap;
    map <Instruction*, int> InstIdMap;
    map <int, vector<int>> loopToExitBlocks;
    map <int, vector <int>> loopBlocks;
    vector <int> visited;
    
    int bid = 0, branches;
    bool startAnalysis = false;

    LLVMContext* pC;
    string moduleName;

    BasicBlock* getBlockbyID(int id);
    bool checkForbidden(string Fname);
    void detectUsefulFunctions(Module& M, Function* main); 

    void getAnalysisUsage(AnalysisUsage &AU) const {
      // pass for getting the loop information
      AU.addRequired<DominatorTreeWrapperPass>();
      AU.addRequired<PostDominatorTreeWrapperPass>();
      AU.addRequired<LoopInfoWrapperPass>();   	    
      AU.setPreservesAll();
    }

    virtual bool doInitialization(Module &M) {

      branches = 0;
      int funcID = 0, loopID = 0;
      pC = &(M.getContext());
      moduleName = M.getName().str();

      
      Function* main = NULL;

      for (auto &F: M) {
        if (F.hasName() || !F.isDeclaration()) {       
          //store it in a hashmap
          fMap[F.getName()] = funcID;
          funcID++;
          if (F.getName() == "main") {
            main = &F;
            detectUsefulFunctions(M, &F);
          }
        }
      }
      return false;
     }

    virtual bool runOnFunction(Function &F) {

      if(!F.hasName() || F.isDeclaration()) {
        return false;
      }
      Function* Fp = &F; 
      //if (usefulFunctions.count(Fp) == 0) {
        //errs () << "useless: " << fMap[F.getName()] << "\n";
        //return false;
      //}

      //errs() << "Function Name: " << F.getName() << " and ID: " << fMap[F.getName()] << "\n";
      
      //getting the loopinfo
      LoopInfo &LI = getAnalysis<LoopInfoWrapperPass>().getLoopInfo();
      
      
      loopID = 0;  
      int bcount = 0, icount = 0;
      //Getting the bbIdMap and InstIdMap
      for (auto &B: F) {
        bbIdMap[&B] = bcount;
        bcount += 1;
        for (auto &I: B) {
          InstIdMap[&I] = icount;
          icount += 1;
        }
      } 
      //Get all loops
      for (auto &L: LI) {
        getLoops(L);
      }
  
      //iterate through all the loops and figure out all functions that are called inside
      for (const auto& [loopID, loop] : loopMap) {
         vector <int> lBlkIDs = loopBlocks[loopID];
         for (auto bId: lBlkIDs) {
              BasicBlock* BB = getBlockbyID(bId);
              for (auto &I: *BB) {
                  if (dyn_cast<CallInst>(&I)) {
                     CallInst* CI = dyn_cast<CallInst>(&I);
                     Function* CF = CI->getCalledFunction();
                     if (CF && CF->hasName() && !CF->isDeclaration()) {
                        int cfID = fMap[CF->getName()];
                        errs() << "Loop FuncID: " << cfID << "\n";  
                     } 
                  } 
              } 
		 }
      }

     
      bbIdMap.clear();
      loopMap.clear();
      loopBBMap.clear();
      InstIdMap.clear();
      loopToExitBlocks.clear();
      loopBlocks.clear();
      visited.clear();
      return true;
    }

    virtual bool doFinalization(Module &M) {
      errs () << "***********************\n";
      for (const auto& [fName, fID] : fMap) {
        errs () << "FunctionName: " << fName << ", ID: " << fID << "\n";
      }
      errs () << "***********************\n";
      return false;
      }

    //Only outer-loops are fine
    //IDs the loops (current and inner) and stores them
    //also get the loop blocks (which is essential for determining exit blocks) 
    void getLoops(Loop* L) {
    
      //Giving the loops an ID
      loopMap[loopID] = L;
      
      //get all the blocks of the loop
      vector <int> lBlocks;
      for (auto BB = L->block_begin(); BB != L->block_end(); ++BB) {
          lBlocks.push_back(bbIdMap[*BB]);
      }
      loopBlocks[loopID] = lBlocks;

      //increment the global loop counter 
      loopID += 1;

      //get the inner-loop headers if present
      vector <Loop*> subLoops = L->getSubLoops();
      for (auto &subL: subLoops) {
        getLoops(subL);
      }
      return;
    }
 };
  bool LLMPass :: checkForbidden(string Fname) {

    if (builtins.count(Fname) != 0) {                                           
      errs() << "found built-in" << Fname << "\n";                             
      return true;                                                             
    } 
      
    if (Fname.find("_GLOBAL__sub") != string::npos) {
      return true;         
    }

    if (Fname.find("__cxx_global_var_init") != string::npos) {
      return true;         
    }

    if (Fname.find("__gnu_cxx") != string::npos) {                              
       return true;                                                             
    }                                                                           
                                                                                                                                                              
    //forbidden for 511.povray_r                                                
    if (Fname.find("TextStreamBuffer") != string::npos) {                       
        return true;                                                            
    }                                                                           
                                                                                
    //if (Fname.find("POVMSUtil_TempAllocPPvi") != string::npos) {                       
    //  return true;                                                             
    //}                                                                         
                                                                                
    //if (Fname.find("XalanMemMgrs14getDummyMemMgrEv") != string::npos) {                
    //   return true;                                                             
    //}                                                                         
                                                                                
    if (Fname.find("ExecuteOnStartup") != string::npos) {                       
       return true;                                                             
    }                                                                           
                                                                                
    if (Fname.find("CommonStringPool") != string::npos) {                       
        return true;                                                            
    }
    
       if (Fname.find("ExecuteOnStartup") != string::npos) {                       
       return true;                                                             
    }                                                                           
                                                                                
    if (Fname.find("CommonStringPool") != string::npos) {                       
        return true;                                                            
    }                                                                           
                                                                                
    if (Fname.find("cEnvir") != string::npos) {                                 
       return true;                                                             
    }                                                                           
                                                                                
    if (Fname.find("cGlobalRegistrationList") != string::npos) {                
       return true;                                                             
    }                                                                           
                                                                                
    if (Fname.find("cStringPool") != string::npos) {                            
       return true;                                                             
    }

    return false;
  }

  void LLMPass :: detectUsefulFunctions(Module &M, Function *main) {
			CallBase *CB;
			queue<Function*> tempQ;
			tempQ.push(main);
			while(!tempQ.empty()) {
				auto func = tempQ.front();
				tempQ.pop();

				if(usefulFunctions.count(func) > 0) {
					continue;
				}
				usefulFunctions.insert(func);

				for(auto &B : *func) {
                	for(auto &I : B) {
						CB = dyn_cast<CallBase>(&I);
						if(CB) {
							Function *callee = CB->getCalledFunction();
							if(callee && !callee->isDeclaration()) {
								tempQ.push(callee);
							}
						}
					}
				}
			}

//			for(auto &F : M) {
//				if(F.hasAddressTaken()) {
//					if (F.getName().str().find("_GLOBAL__sub") == string::npos) {
//                        usefulFunctions.insert(&F);
//                    }
//				}
//			}
  }

  BasicBlock* LLMPass :: getBlockbyID(int id) {
      for (auto it = bbIdMap.begin(); it != bbIdMap.end(); ++it)
          if (it->second == id)
             return it->first;
      return NULL;
  }  
}

char LLMPass::ID = 0;
static RegisterPass<LLMPass> Y("LLM", "LLMPass"); 

