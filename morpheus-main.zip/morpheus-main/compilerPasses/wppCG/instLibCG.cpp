#include<cstdio>
#include<fstream>
#include<stdint.h>
#include<stdarg.h>
#include<string>
#include <iostream>
#include<utility>
#include <cstring>  
#include <algorithm>
#include <iterator>
#include <vector>
#include <map>
#include <set>
#include <unordered_set>

#define LIMIT 1000000
using namespace std;

long long tokenCount; 
bool loopActive; 
long long looptokens, newlooptokens;


//maps functions to loops to their activations
//FuncID -> [LoopID->[loop activation instances]]
map <int, map <int, vector<int>>> functoLoopToAct;

//Map func ids to their set unique basic blocks 
map <int, set <int>> functoUniqueBBs;

map <string, int> seenLoopPaths;
map <int, int> seenLoopFunctions;


//stores the function calls
vector <string> funcCalls;

//store the loop path
vector <int> tempLoopPath;

map <int, vector <int>> compLoopPath; 

map<int, bool> writeFile;

map <int, int> funcFreq;
map <int, int> funcLoopFreq; 


//Loop distubution map that checks if a certain loop with same distribution was observed before
map <string, vector<int>> loopPathDistribution; 

static std::ofstream f_path;
std::ofstream ue_path;
bool mainSeen = false;

extern "C" void instLib_init(char *file) {

   cout << "Start Inst\n";
   f_path.open(file, std::ios::out | std::ios::app);
}

extern "C" void instLib_main() {
   cout << "Start Inst\n";
   mainSeen = true;
   tokenCount = 0;
   looptokens = 0;
   newlooptokens = 0;
   loopActive = false;
}

/*Function to check if newKey:newValue is present in the loopDistributionMap*/
bool checkIfKeyAndValuePresent(const string& newKey, const vector<int> &newValue) {

   // Check if the key is present in the map
   auto it = loopPathDistribution.find(newKey);

   // If the key is not found, return false
   if (it == loopPathDistribution.end()) {
      return false;
   }

   // Compare the vectors
   vector <int> existingValue = it->second;

   // Check if both vectors have the same size
   if (existingValue.size() != newValue.size()){
      return false;
   }

   // Check if each element of the vectors is equal
   for (int i = 0; i < existingValue.size(); ++i) {
      if (existingValue[i] != newValue[i]) {
         return false;
      }
   } 

   // Both key and value match
   return true;
}

/*****
0. Do the analysis only when unseen tokens are found
1. Analyze the loop distribution in tempLoopPath
2. Check if that loop distribution was seen before
3. If unseen, put it in the map and return True
4. Otherwise return False 
*****/
bool analyzeLoopDist() {
   map <int, int> lFuncFreq; 
   bool seen = true;
   for (auto funcID: tempLoopPath) {
      if (lFuncFreq.count(funcID) == 0) {
         lFuncFreq[funcID] = 0;           
      }
      if (seenLoopFunctions.count(funcID) == 0) {
         seen = false;
         seenLoopFunctions[funcID] = 1; 
      } 
      lFuncFreq[funcID] += 1;
   }
   //terminate the analysis if all tokens are seen earlier
   if (seen) {
      return false;
   }

   //construct the loop key and loop value to check if it was seen before
   //The logic here is that the key is total functions-total occurrences -> exact unique functions in that order
   string loopKey = to_string(lFuncFreq.size()) + "-" + to_string(tempLoopPath.size()); 
   //cout << "Loop Key: " << loopKey << "\n";
   vector <int> loopValue; 
   //cout << "F:T =" << lFuncFreq.size() << ":" << tempLoopPath.size() << " Dist:\n";
   for (auto it = lFuncFreq.begin(); it != lFuncFreq.end(); ++it) {
      //cout << it->first << ":" << it->second << "  ";
      loopValue.push_back(it->first);
   }
   //check if this loop with same distribution was seen before 
   if (!checkIfKeyAndValuePresent(loopKey, loopValue)) {
      loopPathDistribution[loopKey] = loopValue;
      return true; 
   }
   return false;
}

// Helper function to check if all elements in a sub-vector are unique
bool areElementsUnique(const vector<int>& nums, int start, int length) {
    unordered_set<int> elements;
    for (int i = start; i < start + length; ++i) {
        if (elements.find(nums[i]) != elements.end()) {
            return false;  // Duplicate element found
        }
        elements.insert(nums[i]);
    }
    return true;  // All elements are unique
}

/***** 
Finds out the longest non-overlapping substring 
optional: do this only for first 'k' tokens (since vector can be very big)
Function to find the longest repeating, non-overlapping sub-vector with unique elements
*****/
vector<int> longestRepeatingNonOverlappingUniqueSubVector(const vector<int>& nums) {
   int n = nums.size();
   cout << "DP\n";
   // dp[i][j] stores the length of the longest common sub-vector ending at index i and j
   vector<vector<int>> dp(n + 1, vector<int>(n + 1, 0));
   int maxLength = 0;
   int startIndex = -1;  // To store the starting index of the longest repeating sub-vector

   // Iterate over all possible pairs (i, j)
   for (int i = 1; i <= n; ++i) {
      for (int j = i + 1; j <= n; ++j) {
         // If elements match and they are non-overlapping
         if (nums[i - 1] == nums[j - 1] && j - i > dp[i - 1][j - 1]) {
            dp[i][j] = dp[i - 1][j - 1] + 1;

            // Check if the sub-vector from i - maxLength to i has unique elements
            if (dp[i][j] > maxLength && areElementsUnique(nums, i - dp[i][j], dp[i][j])) {
               maxLength = dp[i][j];
               startIndex = i - maxLength;  // Calculate starting index of the sub-vector
            }
         } 
         else {
            dp[i][j] = 0;  // No matching, reset the count
         }
      }
   }
   // If a sub-vector was found, extract it
   vector<int> result;
   if (startIndex != -1) {
      for (int i = startIndex; i < startIndex + maxLength; ++i) {
         result.push_back(nums[i]);
      }
   }
   return result;  // Return the longest sub-vector
}

/*** 
// Function to find the starting index of the first instance of sub-vector in a vector
***/
int findSubVector(const vector<int>& vec, const vector<int>& subVec) {
    int n = vec.size();
    int m = subVec.size();

    // Edge case: if sub-vector is larger than the main vector, it can't exist
    if (m > n) return -1;

    // Sliding window approach
    for (int i = 0; i <= n - m; ++i) {
        bool found = true;
        for (int j = 0; j < m; ++j) {
            if (vec[i + j] != subVec[j]) {
                found = false;
                break;
            }
        }
        if (found) return i;  // Return the starting index if sub-vector is found
    }

    return -1;  // Return -1 if sub-vector is not found
}

// Function to check if subVec matches vec starting at index i
bool isSubVectorAt(const vector<int>& vec, const vector<int>& subVec, int i) {
    int m = subVec.size();
    for (int j = 0; j < m; ++j) {
        if (vec[i + j] != subVec[j]) {
            return false;
        }
    }
    return true;
}

//Find and replace all occurences of longest substr
// Function to remove all instances of subVec in vec and return the modified vector
vector<int> removeSubVector(vector<int>& vec, const vector<int>& subVec) {
   int n = vec.size();
   int m = subVec.size();
    
   if (m == 0 || n == 0 || m > n) return vec;  // Edge cases
   for (int i = 0; i <= n - m;) {
      // Check if subVec is found at position i
      if (isSubVectorAt(vec, subVec, i)) {
         // Erase the sub-vector from the main vector
         vec.erase(vec.begin() + i, vec.begin() + i + m);
         // Update the size of the vector since we modified it
         n = vec.size();
      } 
      else {
         ++i;  // Move to the next position if no match is found
      }
   }
   return vec;  // Return the modified vector
}

// Function to remove contiguous repeating elements in a vector - for recursion
vector<int> removeContiguousRepeats(const vector<int>& vec) {
   if (vec.empty()) {
      return vec;  // Return an empty vector if the input vector is empty
   }

   vector<int> result;
   result.push_back(vec[0]);  // Always include the first element
   // Traverse the vector, starting from the second element
   for (int i = 1; i < vec.size(); ++i) {
      // Only add the element if it's different from the previous one
      if (vec[i] != vec[i - 1]) {
         result.push_back(vec[i]);
      }
   }
   return result;  // Return the modified vector
}

// Function to copy values from the map into a new vector in increasing order of keys
void copyValuesInOrder(const map<int, vector<int>>& compLoopPath, vector <int>& result) {
   
   // Iterate through the map (automatically sorted by keys in increasing order)
   for (const auto& pair : compLoopPath) {
      const vector<int>& values = pair.second;  // Get the vector associated with the key
      // Append all values from this vector to the result vector
      result.insert(result.end(), values.begin(), values.end());
   }
}


/**** 
Optional TODO: Checks if any of the seen patterns are present in the new loop path vector
****/
extern "C" void checkSeenPatterns() {
   //TODO
   return;
}

/***compacts the active loop paths
 * 0. Remove all instances of recursion in the loop path
 * 1. Check if same loop and its distribution was seen before (only do analysis for unseen distribution)
 * 2. Find out the longest repeating, non-overlapping, unique subvector
 * 3. Assign a priority number to the subvector for distinguishing the context (relative order)
 * 4. Replace all occurrences of the subvector in the original vector
 * 5. Repeat Step 2-4 - untill new length is less than half the original length (CAN BE ADJUSTED)
 * 6. (Optional TODO) Store the pattern 
 * ***/
vector<int> onlineCompression(bool doAll) {
   
   vector <int> compLoop;

   //Step 0 : Remove all instances of recursion
   tempLoopPath = removeContiguousRepeats(tempLoopPath);

   //Step 1: Check if this distrubution was seen before
   bool analysisNeeded = analyzeLoopDist();
   if (!analysisNeeded) {
      //cout << "seen loop\n";
      return compLoop;
   }
   //Goal is to transform tempLoopPath -> compLoop

   //copy of the original vector - for determining where subvector fits in the original path
   vector <int> newtempLoopPath;
   for (int element : tempLoopPath) {
      newtempLoopPath.push_back(element);
   }

   uint newSize = newtempLoopPath.size(); 
   uint oldSize = tempLoopPath.size();
   uint limitSize = 0;
   if (doAll) {
      limitSize = oldSize/2;
   }
   //cout << "old size: " << tempLoopPath.size() << "\n";
   
   do {
      //Step 2: Check the longest repeating and non-overlapping substring 
      //TODO: instead of recalculating make a lookup table
      //TODO?: Do the analysis only when new functions are in the buffer?
      vector<int> repVec = longestRepeatingNonOverlappingUniqueSubVector(newtempLoopPath);
      cout << "Size of Repeating Vector: " << repVec.size() << "\n";
      if (repVec.empty()) {
         compLoopPath[oldSize-1] = newtempLoopPath;
         newtempLoopPath.clear();
         newSize = 0;
         break;
      }
      //Step 3: Determine the relative order of repeating vector (in the old one)
      int vecInd = findSubVector(tempLoopPath, repVec); 
      //cout << "first occurence: " << vecInd << "\n";
      
      //add this in a map with occurence->subvector - this is the order in which we'll write stuff
      compLoopPath[vecInd] = repVec;

      //Step 4: Replace all occurences of the subvector in the original
      newtempLoopPath = removeSubVector(newtempLoopPath, repVec); 
  
      //Step 5: check if loops needs more extraction (Steps 2 - 4)
      cout << "new size: " << newtempLoopPath.size() << "\n";
      newSize =  newtempLoopPath.size();
      
   } while (newSize > limitSize);
   //newSize > oldSize/2 
    
   //Step 6: Create the compressed representation of loop
   copyValuesInOrder(compLoopPath, compLoop);
   
   //clearing the loop path & the map
   //tempLoopPath.clear();
   if (doAll) {
      tempLoopPath = newtempLoopPath;
   }
   newtempLoopPath.clear();
   compLoopPath.clear(); 
   return compLoop;
} 

extern "C" void printMegaPath(){

   //check is file is open or not
   if (!f_path.is_open()) {
       f_path.open("wpp_dataCG.prof", std::ios::out | std::ios::app);
   }
   
   for (auto it = funcCalls.begin(); it != funcCalls.end(); ++it) {
      //pair <int, int> x = *it;  
      f_path << *it << ",";
   }
   cout << "\n";
}

/*This is just for summary stats*/
extern "C" void printKeys() {

   //for (auto it = funcFreq.begin(); it != funcFreq.end(); ++it) {
   //   cout << "Func: " << it->first << " with " << it->second << " Occurences and Loop Freq: " << funcLoopFreq[it->first] << "\n";
   //}
   cout << "total tokens: " << tokenCount << "\n";
   cout << "loop tokens: " << looptokens << "\n";
   cout << "new loop tokens " << newlooptokens << "\n";  
 
}

extern "C" void instLib_fini() {
   
   cout << "Finish Inst\n";
   mainSeen = false;
   //print out the data structures for reference
   printKeys();

   //write the profile to a file
   //printMegaPath();
   f_path.close();
}

/**
This function gets triggered whenever a function call is encountered
1. If no loop is active:
   a. It checks if the loop buffer has any contents
   b. If yes, it triggers online-compression and stores it wpp trace
   c. it then simply prints out the current function-ID in the wpp trace
2. If loop is active:
   a. it stores the loop token in the loop buffer
   b. if the loop buffer has exceeded a certain limit, it triggers the online-compression
**/
extern "C" void instLib_bb_info(uint64_t funcID) {  
   
   if (!mainSeen) {
      return; 
   }
   //cout << "FuncID: " << funcID << "\n";
   //increment the token counter
   tokenCount += 1;
   //special case for 526.blender_r
   //if (funcID == 36827) {
   //cout << "t: " << tokenCount << "\n";
   //}

   //create a hashMap
   //search for funcID in map
   if (funcFreq.count(funcID) == 0) {
      funcFreq[funcID] = 0;           
   }
   funcFreq[funcID] += 1;

   //Check for any active loop instances - recursion! 
   loopActive = false;
   for (const auto& [funcID, loopToActMap] : functoLoopToAct) {
      for (const auto& [loopID, activationVec] : loopToActMap) {
         if (activationVec.size() > 0) {
         loopActive = true;
         } 
      }  
   }
   //printing only is loop is not active   
   if (!loopActive) {
      if (!f_path.is_open()) {
         f_path.open("wpp_dataCG.prof", std::ios::out | std::ios::app);
      }
      //before printing any anything, check if there's stuff in buffer 
      if (!tempLoopPath.empty()) {
         //perform compression

         //for (auto it : tempLoopPath) {
         //   cout << it << " ";
         //}
         //cout << "\n";
         vector<int> compPath = onlineCompression(true);
         if (!compPath.empty()) {
            //add markers for hot region
            compPath.insert(compPath.begin(), -1);
            compPath.push_back(-1);     
            //cout << "compressed size:" << compPath.size() << "\n";
            newlooptokens += compPath.size();
            //write the compressed path in file
            for (auto lid : compPath) {
               string s = to_string(lid);
               f_path << s << ",";
            }
         }
         //clearing the temporary buffer
         tempLoopPath.clear();
      }
      //generate the current funcID string
      string s1 = to_string(funcID);
      //cout << s1 << ",";
      f_path << s1 << ","; 
   }
   else {
      //Loop is active, store contents in a buffer
      tempLoopPath.push_back(funcID);
      //if buffer size exceeds a limit, trigger compression manually 
      //TODO - trigger not to clean the loop path completely
      if (tempLoopPath.size() > 10000) {
         //cout << "Loop Buffer Size: " << tempLoopPath.size() << "\n";
         vector <int> compPath = onlineCompression(false);
         if (!compPath.empty()) {
            //add markers for hot region
            compPath.insert(compPath.begin(), -1);
            //compPath.push_back(-1);
            newlooptokens += compPath.size();
            if (!f_path.is_open()) {
               f_path.open("wpp_dataCG.prof", std::ios::out | std::ios::app);
            }
            //write the compressed path in file
            for (auto lid : compPath) {
               string s = to_string(lid);
               f_path << s << ",";
            }   
         }
         tempLoopPath.clear();
         //cout << "Updated Loop Buffer Size: " << tempLoopPath.size() << "\n";
      }
      
   
      looptokens += 1;
      if (funcLoopFreq.count(funcID) == 0) {
         funcLoopFreq[funcID] = 0;           
      }
      funcLoopFreq[funcID] += 1;
   }   
}

//Mark the loop start
extern "C" void instLib_loop_activate(uint64_t loopID, int funcID) {

   if (!mainSeen) {
      return; 
   }
   //cout << "loop activation" << loopID <<  " function: " << funcID << "\n";
   
   //search for loop in file funcID
   if (functoLoopToAct.count(funcID) == 0) {
      //cout << "func: " << funcID << "not found\n";
      map <int, vector<int>> temploopToActVec;
      functoLoopToAct[funcID] = temploopToActVec;
   }

   //cout << "function, loop initialized " << loopID << "\n";
   map <int, vector<int>> loopToAct = functoLoopToAct[funcID];

   if (loopToAct.count(loopID) == 0) {
      vector<int> tempActivation;
      loopToAct[loopID] = tempActivation;
   }
   //activate the loop
   //cout << "Activating Loop" << loopID << "," << funcID << "\n";
   loopToAct[loopID].push_back(1);
   functoLoopToAct[funcID] = loopToAct;
   return; 
}

//Mark the loop end
extern "C" void instLib_loop_deactivate(uint64_t loopID, int funcID) {
   if (!mainSeen) {
      return; 
   }
   //cout << "loop de-activation" << loopID << " Function " << funcID << "\n";
   //cout << "Deactivating" << loopID << "," << funcID << "\n";
   //searching for the func ID
   if (functoLoopToAct.count(funcID) == 0) {
    return; 
   }
   map <int, vector<int>> loopToAct = functoLoopToAct[funcID];
   //searching for the loop ID 
   if (loopToAct.count(loopID) == 0) {
    return;
   }
   //deactivate the loop
   if (!loopToAct[loopID].empty()) {
      loopToAct[loopID].pop_back();
   }
   

   //cout << "Local Trip Count of Loop "  << loopID << ", Function " << funcID << " = " << loopToTripCount[loopID] - 1 << "\n";
   //update the map
   functoLoopToAct[funcID] = loopToAct;
}