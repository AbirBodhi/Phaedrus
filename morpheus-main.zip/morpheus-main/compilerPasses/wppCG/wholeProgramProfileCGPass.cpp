#include "llvm/Pass.h"
#include "llvm/IR/Function.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"

#include "llvm/Analysis/LoopInfo.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Dominators.h"
#include "llvm/Analysis/PostDominators.h"

#include "llvm/IR/IRBuilder.h"

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <tuple>
#include <algorithm>

using namespace llvm;
using namespace std;

namespace {
  struct wholeProgramProfileCGPass : public FunctionPass {
    static char ID;

    map <StringRef, int> fMap;
    set<string> builtins;
    wholeProgramProfileCGPass() : FunctionPass(ID) {}
    vector <int> forbidden; 

    map <BasicBlock*, int> bbIdMap;
    map <int, int> loopBBMap;
    set <Function*> usefulFunctions; 

    int loopID;
    map <int, Loop*> loopMap;
    map <Instruction*, int> InstIdMap;
    map <int, vector<int>> loopToExitBlocks;
    map <int, vector <int>> loopBlocks;
    vector <int> visited;
    
    int bid = 0, branches;
    bool startAnalysis = false;

    LLVMContext* pC;
    FunctionCallee instLib_bb_info, instLib_main, instLib_fini, 
    instLib_loop_activate, instLib_loop_deactivate; 
    string moduleName;

    BasicBlock* getBlockbyID(int id);
    void instrumentInitialization(Function &F);
    void printInstrumentation(Function &F);
    void finish_inst(Function &F);
    bool checkForbidden(string Fname);
    void detectUsefulFunctions(Module& M, Function* main); 

    void getAnalysisUsage(AnalysisUsage &AU) const {
      // pass for getting the loop information
      AU.addRequired<DominatorTreeWrapperPass>();
      AU.addRequired<PostDominatorTreeWrapperPass>();
      AU.addRequired<LoopInfoWrapperPass>();   	    
      AU.setPreservesAll();
    }

    virtual bool doInitialization(Module &M) {

      branches = 0;
      int funcID = 0, loopID = 0;
      pC = &(M.getContext());
      moduleName = M.getName().str();
      IRBuilder<> IRB(*pC);

      instLib_bb_info = M.getOrInsertFunction("instLib_bb_info", IRB.getVoidTy(), IRB.getInt64Ty());
      instLib_main = M.getOrInsertFunction("instLib_main", IRB.getVoidTy());
      instLib_fini = M.getOrInsertFunction("instLib_fini", IRB.getVoidTy());
      instLib_loop_activate = M.getOrInsertFunction("instLib_loop_activate", IRB.getVoidTy(), IRB.getInt64Ty(), IRB.getInt64Ty());
      instLib_loop_deactivate = M.getOrInsertFunction("instLib_loop_deactivate", IRB.getVoidTy(), IRB.getInt64Ty(), IRB.getInt64Ty());
      
      Function* main = NULL;

      for (auto &F: M) {
        if (F.hasName() || !F.isDeclaration()) {       
          //store it in a hashmap
          fMap[F.getName()] = funcID;
          funcID++;
          if (F.getName() == "main") {
            main = &F;
            detectUsefulFunctions(M, &F);
          }
        }
      }
      //mainSeen = false;
      return false;
     }

    virtual bool runOnFunction(Function &F) {

      if(!F.hasName() || F.isDeclaration()) {
        return false;
      }
      Function* Fp = &F; 
      if (usefulFunctions.count(Fp) == 0) {
        errs () << "useless: " << fMap[F.getName()] << "\n";
        //return false;
      }
      //Performing the instrumentations in reverse-order in which they're supposed to appear
      //3. loop preheader and loop exits
      //2. function entry
      //1. main - If present

      errs() << "Function Name: " << F.getName() << " and ID: " << fMap[F.getName()] << "\n";
      
      //getting the loopinfo
      LoopInfo &LI = getAnalysis<LoopInfoWrapperPass>().getLoopInfo();
      
      uint bcount = 0, icount = 0;
      //Getting the bbIdMap and InstIdMap
      for (auto &B: F) {
        bbIdMap[&B] = bcount;
        bcount += 1;
        for (auto &I: B) {
          InstIdMap[&I] = icount;
          icount += 1;
        }
      }
      loopID = 0;   
      //Get all loops
      for (auto &L: LI) {
        getLoops(L);
      }
  
      //iterate through all the loops and instrument them
      for (const auto& [loopID, loop] : loopMap) {
        //errs () << "loop: " << loopID << ", FuncID: " << fMap[F.getName()] << "\n";
        instrumentLoop(loop, loopID, fMap[F.getName()]);
      }

      //instrumenting the first point of each function      
      Instruction *begin = &*(F.getEntryBlock().getFirstInsertionPt());
      IRBuilder<> IRB(begin);
      
      //Ensures no instrumentation actually happens in the lib until main
      if(F.getName() == "main") { 
        IRB.CreateCall(instLib_main,{});
      } 
      //Add the finalization after the custom instrumentation
      if (F.getName() == "main") {
        finish_inst(F);
      }

      IRB.CreateCall(instLib_bb_info, {ConstantInt::get(Type::getInt64Ty(*pC), fMap[F.getName()])});
     
      bbIdMap.clear();
      loopMap.clear();
      loopBBMap.clear();
      InstIdMap.clear();
      loopToExitBlocks.clear();
      loopBlocks.clear();
      visited.clear();
      return true;
    }

    virtual bool doFinalization(Module &M) {
      errs () << "***********************\n";
      errs () << "***********************\n";
      return false;
      }

    //Only outer-loops are fine
    //IDs the loops (current and inner) and stores them
    //also get the loop blocks (which is essential for determining exit blocks) 
    void getLoops(Loop* L) {
    
      //Giving the loops an ID
      loopMap[loopID] = L;
      
      //get all the blocks of the loop
      vector <int> lBlocks;
      for (auto BB = L->block_begin(); BB != L->block_end(); ++BB) {
          lBlocks.push_back(bbIdMap[*BB]);
      }
      loopBlocks[loopID] = lBlocks;

      //increment the global loop counter 
      loopID += 1;

      //get the inner-loop headers if present
      //vector <Loop*> subLoops = L->getSubLoops();
      //for (auto &subL: subLoops) {
      //  getLoops(subL);
      //}
      return;
    }
    
    //Instrument the loop to get trip counts
    //1. Each time a particular loop is called (loop header instruement), activate it
    //2. Deactivate the loop each time the loop is exited (get all exit blocks) & store it
    void instrumentLoop(Loop* L, int loopID, int funcID) {
     
      //Getting the first loop pre-header and instrumentation point
      BasicBlock* loopHeader = L->getLoopPreheader();
      Instruction* LoopHeaderI = &*(loopHeader->getFirstInsertionPt());
          
      //Saving the loop header's branch 
      //(used later for distinguishing conditionals) 
      //Instruction* loopBr = loopHeader->getTerminator();
      //loopHeaders.push_back(InstIdMap[loopBr]);

      //errs() << "Insertion Point: " << *LoopHeaderI << "\n";
      //string FuncName = (BB->getFunction())->getName().str();
  
      //At loop header, activate the loop
      IRBuilder<> IRB(LoopHeaderI);
      IRB.CreateCall(instLib_loop_activate, {ConstantInt::get(Type::getInt64Ty(*pC), loopID), ConstantInt::get(Type::getInt64Ty(*pC), funcID)});

      //get the exit blocks of loops
      populateLoopExitBlocks(loopHeader, loopID);
      vector <int> loopExitBlocks = loopToExitBlocks[loopID];
      //errs () << "total exit blocks : " << loopToExitBlocks.size() << "\n";
      
      //instrument each exit blocks to deactivate the loop
      for (auto blockID : loopExitBlocks) {
	      if(getBlockbyID(blockID) == nullptr) {
	        continue;
	      }
      Instruction* eI = getBlockbyID(blockID)->getTerminator();
      //errs() << "loop exit block\n";
      IRBuilder<> IRB2(eI);
      //Value *line2 = IRB2.CreateGlobalStringPtr(StringRef(FuncName));
      //errs() << "instrumenting exit block: \n";
      IRB2.CreateCall(instLib_loop_deactivate, {ConstantInt::get(Type::getInt64Ty(*pC), loopID), ConstantInt::get(Type::getInt64Ty(*pC), funcID)});
      }
  return;      
 }

    //Populate the exit blocks of each loop mapped with their IDs
    void populateLoopExitBlocks(BasicBlock* loopHeader, int loopID) {
      visited.clear();
      //Do the loop explore
      loopExplore(loopHeader, loopID);
      return;
 }

    //Perform a DFS-like traversal of loop to populate the loop exit blocks
    void loopExplore(BasicBlock* BB, int loopID) {

    visited.push_back(bbIdMap[BB]);

    //Getting the successors of the loop block
    vector <BasicBlock*> succs;
    for (succ_iterator sit = succ_begin(BB), set = succ_end(BB); sit != set; ++sit) {
        succs.push_back(*sit);
    }

    //For each successor, check if they're not visited and whether don't belong to loop
    for (auto succBB: succs) {
      if ((find(visited.begin(), visited.end(), bbIdMap[succBB]) == visited.end())) {
        if (!checkLoopBlock(loopID, succBB)) {
            vector<int> tempLoopExitBBs = loopToExitBlocks[loopID];
            tempLoopExitBBs.push_back(bbIdMap[succBB]);
            loopToExitBlocks[loopID] = tempLoopExitBBs;
        }
        else {
          //Explore them if they're not visited & part of loop
          loopExplore(succBB, loopID);
        }
      }
    } 
 }
  
    /*Checks if BasicBlock B belongs to loop (with LoopID)*/
    bool checkLoopBlock(int LoopID, BasicBlock* B) {

    vector <int> tempBBVec = loopBlocks[LoopID];
    int BBid = bbIdMap[B];
    if (find(tempBBVec.begin(), tempBBVec.end(), BBid) != tempBBVec.end()) { 
      return true; 
    }
    return false;
 }

  };
  bool wholeProgramProfileCGPass :: checkForbidden(string Fname) {

    if (builtins.count(Fname) != 0) {                                           
      errs() << "found built-in" << Fname << "\n";                             
      return true;                                                             
    } 
      
    if (Fname.find("_GLOBAL__sub") != string::npos) {
      return true;         
    }

    if (Fname.find("__cxx_global_var_init") != string::npos) {
      return true;         
    }

    if (Fname.find("__gnu_cxx") != string::npos) {                              
       return true;                                                             
    }                                                                           
                                                                                                                                                              
    //forbidden for 511.povray_r                                                
    if (Fname.find("TextStreamBuffer") != string::npos) {                       
        return true;                                                            
    }                                                                           
                                                                                
    //if (Fname.find("POVMSUtil_TempAllocPPvi") != string::npos) {                       
    //  return true;                                                             
    //}                                                                         
                                                                                
    //if (Fname.find("XalanMemMgrs14getDummyMemMgrEv") != string::npos) {                
    //   return true;                                                             
    //}                                                                         
                                                                                
    if (Fname.find("ExecuteOnStartup") != string::npos) {                       
       return true;                                                             
    }                                                                           
                                                                                
    if (Fname.find("CommonStringPool") != string::npos) {                       
        return true;                                                            
    }
    
       if (Fname.find("ExecuteOnStartup") != string::npos) {                       
       return true;                                                             
    }                                                                           
                                                                                
    if (Fname.find("CommonStringPool") != string::npos) {                       
        return true;                                                            
    }                                                                           
                                                                                
    if (Fname.find("cEnvir") != string::npos) {                                 
       return true;                                                             
    }                                                                           
                                                                                
    if (Fname.find("cGlobalRegistrationList") != string::npos) {                
       return true;                                                             
    }                                                                           
                                                                                
    if (Fname.find("cStringPool") != string::npos) {                            
       return true;                                                             
    }

    return false;
  }

  void wholeProgramProfileCGPass :: detectUsefulFunctions(Module &M, Function *main) {
			CallBase *CB;
			queue<Function*> tempQ;
			tempQ.push(main);
			while(!tempQ.empty()) {
				auto func = tempQ.front();
				tempQ.pop();

				if(usefulFunctions.count(func) > 0) {
					continue;
				}
				usefulFunctions.insert(func);

				for(auto &B : *func) {
                	for(auto &I : B) {
						CB = dyn_cast<CallBase>(&I);
						if(CB) {
							Function *callee = CB->getCalledFunction();
							if(callee && !callee->isDeclaration()) {
								tempQ.push(callee);
							}
						}
					}
				}
			}

//			for(auto &F : M) {
//				if(F.hasAddressTaken()) {
//					if (F.getName().str().find("_GLOBAL__sub") == string::npos) {
//                        usefulFunctions.insert(&F);
//                    }
//				}
//			}
  }

  BasicBlock* wholeProgramProfileCGPass :: getBlockbyID(int id) {
      for (auto it = bbIdMap.begin(); it != bbIdMap.end(); ++it)
          if (it->second == id)
             return it->first;
      return NULL;
  }  

	//This will instrument the function that dumps all info at the end of the function
	void  wholeProgramProfileCGPass :: printInstrumentation(Function &F) {

		auto FuncName = F.getName();  
		vector<Instruction*> ExitBlocks;
		for (BasicBlock &B : F) {
			if (isa<ReturnInst>(B.getTerminator())) {
				ExitBlocks.push_back(B.getTerminator());
			}
			else if(isa<UnreachableInst>(B.getTerminator())) {
				if(B.getTerminator()->getPrevNode()) {
					ExitBlocks.push_back(B.getTerminator()->getPrevNode());
				}
				else {
				ExitBlocks.push_back(B.getTerminator());
				} 
			}
		}        
	}

  void wholeProgramProfileCGPass :: finish_inst(Function &F) {

      /* Create instLib_fini function at each Exit block */
      //startAnalysis = false;
      vector<Instruction*> ExitBlocks;
      for (BasicBlock &B : F) {
        if (isa<ReturnInst>(B.getTerminator())) {
            ExitBlocks.push_back(B.getTerminator());
        }
        else if(isa<UnreachableInst>(B.getTerminator())) {
            if(B.getTerminator()->getPrevNode()) {
                ExitBlocks.push_back(B.getTerminator()->getPrevNode());
            }
            else {
              ExitBlocks.push_back(B.getTerminator());
            } 
        }
      }        
      for(auto i : ExitBlocks) {
         IRBuilder<> IRBEnd(i);
          IRBEnd.CreateCall(instLib_fini, {});
      }  
  }
}
char wholeProgramProfileCGPass::ID = 0;
static RegisterPass<wholeProgramProfileCGPass> Y("WPPPCG", "wholeProgramProfileCGPass"); 

