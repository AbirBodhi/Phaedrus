#include <stdio.h>
#include <stdlib.h>

int main() {
      
    int a; 

    while (1) {

        a += rand() % 10; 
        if (a > 10)
           break;
    }
    return 0;
}