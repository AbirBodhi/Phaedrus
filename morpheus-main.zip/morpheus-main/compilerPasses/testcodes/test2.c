#include <stdio.h>
#include <stdlib.h>

int main() {
      
    int num = 100, a = 0;
    if (num % 2) {
        a = num;
    }

    for (int i = 0; i < 10; ++i) {
        a = num * i;
    }
    
    return 0;
}