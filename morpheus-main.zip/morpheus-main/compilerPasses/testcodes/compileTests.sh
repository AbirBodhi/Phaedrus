echo "Compiling Unit Tests with WPP Pass"

declare -a ben=( test1 )
#declare -a ben=( test1 )

for j in "${ben[@]}"                                                            
do                                                                              
   echo $j                                                                      

   rm *.ll *.bc *.s *.prof

   echo "CLANG"
   clang -Wall -emit-llvm -S "$j".c -o "$j"_linked.ll 
   clang++ -emit-llvm -S ../src/instLib.cpp 
     
   echo "OPT"
   opt -load ../build/src/libwholeProgramProfilePass.so --WPPP -loop-simplify "$j"_linked.ll > "$j"_wpp1.ll

   echo "LLVM-LINK"
   #llvm-link "$j".ll instLib.ll -o "$j"_linked.ll
   llvm-link "$j"_wpp1.ll instLib.ll -o "$j"_wpp2.bc

   llvm-dis "$j"_wpp2.bc -o "$j"_wpp2.ll

   echo "LLC"
   llc "$j"_wpp2.bc -o "$j"_wpp.s 

   echo "Clang"
   clang++ "$j"_wpp.s -o "$j"_wpp  

   echo "Execution"
   ./"$j"_wpp                                                     
done