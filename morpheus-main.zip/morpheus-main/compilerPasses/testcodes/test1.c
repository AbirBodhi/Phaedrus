#include <stdio.h>
#include <stdlib.h>

int main() {
      
    int num = rand() % 100, a = rand() % 20;

        for (int i = 0; i < 2; ++i) {
        if (a) {
            for (int j = 0; j < 2; ++j) {
                  a += (i*j);
              }
           }
        }   
    
    return 0;
}