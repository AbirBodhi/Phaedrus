#include <stdio.h>
#include <stdlib.h>

int main() {
      
    int num = rand() % 100, a = rand() % num; 
    if (num % 2) {
        if (num % 10) {
            return 0;
        }
    }
    
    else {
         if (a % 2) {
            return 0;
         }
    }

    for (int i = 0; i < 100; ++i) {
        for (int j = 0; j < 100; ++j) {
            a += (i*j);
        }
    }
    return 0;
}