# Phaedrus: Predicting Dynamic Application Behavior with Lightweight Generative Models and LLMs - Artifact Evaluation

GITHUB PUBLIC REPO LINK: https://github.gatech.edu/bchatterjee8/morpheus

## Introduction

This artifact implements **Phaedrus**, a compiler-assisted deep learning framework for predicting dynamic application behavior across varied execution instances. The artifact supports the paper's core contributions through two main approaches:

1. **Application Behavior Synthesis**: LLM-based inference of dynamic functions from source code and static analysis
2. **Application Profile Generalization**: Generative models trained on compressed Whole Program Path (WPP) function profiles

### Important Note: Artifact Status

**This paper is currently under major revision**, and this artifact submission is designed for **kick-the-tires evaluation**. The artifact demonstrates that all compiler passes build successfully and provides actual logs and data to validate the core technical approach. Reviewers should expect:

- ✅ All LLVM passes compile and execute correctly
- ✅ Complete workflow demonstration with sample data
- ✅ Actual experimental logs and results
- ⚠️ **PGO (Profile-Guided Optimization) results may change** as new experimental data is being incorporated during the revision process

**Note on SPEC2017 Benchmarks**: Our analysis was conducted on SPEC CPU 2017 benchmarks. Since SPEC2017 is not open source, the benchmark source code is not included in this artifact. However, **all SPEC2017 experimental logs and data are provided** in the artifact directories (`compression/raw_data/`, `compression/StaticData/`, `train/compLogs/`, etc.). If reviewers require access to the actual SPEC2017 benchmarks for verification, we can provide access upon request.



## Hardware Dependencies

### Minimum Requirements
- **CPU**: x86-64 processor with at least 4 cores
- **Memory**: 8GB RAM minimum (16GB recommended for ML training)
- **Storage**: 5GB free disk space for artifact and intermediate files
- **OS**: Linux (Ubuntu 18.04+) or macOS (10.14+)

### Recommended Configuration
- **CPU**: 8+ cores for parallel compilation and training
- **Memory**: 32GB RAM for training on larger datasets
- **Storage**: 20GB for complete benchmark data and models
- **GPU**: Not required

### Software Dependencies
- **LLVM**: Version 15.0 with development headers (tested version - see LLVM 15 Installation Instructions below) (or any version which supports the old pass manager)
- **CMake**: Version 3.1+
- **Python**: Version 3.7+ with pip
- **C++ Compiler**: GCC 7+ or Clang 8+

### Access Instructions
All experiments can be run on standard academic computing resources. No special hardware access required. For reviewers without adequate local resources:
- Contact artifact authors for access to pre-computed results if computational resources are limited

## Getting Started Guide (≈30 minutes)

This guide will set up the basic environment and run a small test to verify the artifact works correctly.

### Step 1: Environment Setup (10 minutes)

```bash
# Install LLVM 15 and development tools (see LLVM 15 Installation Instructions below)

# Install Python dependencies
pip3 install torch numpy matplotlib

# Verify installations
llvm-config-15 --version
python3 -c "import torch; print(torch.__version__)"
```

**Note**: If LLVM 15 is not installed, please refer to the "LLVM 15 Installation Instructions" section at the end of this document.

### Step 2: Build Compiler Passes (10 minutes)

```bash
cd compilerPasses
mkdir build && cd build
cmake ..
make -j4
cd ..
```

**Expected Output**: Successful compilation with `libwholeProgramProfilePass.so` generated in `build/wppCG/`

### Step 3: Run Basic Test (5 minutes)

```bash
cd testcodes
./compileTests.sh
```

**Expected Output**: 
- Compilation messages for test1.c
- Execution of instrumented binary
- Generated `.ll`, `.bc`, and profile files

### Step 4: Test Data Compression (5 minutes)

```bash
cd ../../compression
python3 dataCompress.py 519.lbm_r small
```

**Expected Output**:
```
path encodings: {'9-10-11': 150, '12-13-14': 151, ...}
519.lbm_r small
before compression: 15847
after compression: 1023
```

### Troubleshooting
- **LLVM not found**: Ensure `llvm-config-15` is in PATH
- **Permission errors**: Run with appropriate user permissions
- **Missing files**: Verify all submodules are checked out

## Step-by-Step Instructions

### Stage 1: Collecting Whole Program Profiles - Smart Loop Instrumentation (Section 4.1)

**Purpose**: Generate compacted Whole Program Path (WPP) profiles using smart loop instrumentation with online compression

```bash
# Test the smart loop instrumentation on a simple example
cd compilerPasses/testcodes
./compileTests.sh
```

**Expected Output**:
- Successful compilation with `libwholeProgramProfilePass.so`
- Generated `test1_wpp` instrumented binary
- Created `wpp_dataCG.prof` with compressed function call traces
- Console output showing compression statistics

### Stage 2: Identifying Compressible Regions - Static Program Analysis (Section 4.2)

**Purpose**: Analyze control dependencies using post-dominator trees and bit-vector algorithm to identify compressible regions

```bash
# Test the static analysis pass on a simple example
cd compilerPasses/testcodes
clang -emit-llvm -S test1.c -o test1.ll
opt -load ../build/staticAnalysis/libgetCGPass.so --CGP -enable-new-pm=0 < test1.ll > test1_static.bc

# View static analysis results for SPEC CPU benchmarks
# (Note: Pre-computed results are available in compression/StaticData/)
cd ../../compression/StaticData/519.lbm_r
cat CG_static.log
```

**Expected Output**:
- Function adjacency lists (control flow graph in adjacency list format)
- Control dependency mappings for each function call
- Branch target IDs on which function calls are control dependent

**Sample Output Format**:
```
Function Adjacency List
31:
32 34 17 16 7 20 16 7 20 20 27 22 4 4 
Control Dependency:
0 0 142 142 142 146 143 143 151 0 159 160 162 162
```



### Stage 3: Input-Consistent Compression (Section 4.3)

**Purpose**: Apply compression scheme from static analysis to WPP profiles, achieving input-consistent compression

```bash
# Apply input-consistent compression to collected WPP profiles
cd compression
python3 dataCompress.py 519.lbm_r small
```

**Expected Output**:
```
path encodings: {'9-10-11': 150, '12-13-14': 151, ...}
519.lbm_r small
15847
performing input-consistent compression
after compression: 1023
```

- Function call sequences grouped by same control dependencies are encoded into single path codes
- Sub-path matching replaces repeated sequences with compressed codes  
- Achieves 50-200× compression ratios while maintaining input consistency
- **Actual compressed profiles from our experiments are provided in `compression/write_data/` directory**

### Stage 4: Augmenting Whole Program Profiles & Sequence Prediction (Sections 4.4 & 4.5)

**Purpose**: Augment compressed profiles with unseen paths and train RNN models for dynamic function call prediction

```bash
# Train RNN models on augmented compressed profiles
cd train
python3 wppCG_train.py
```

**Expected Output**:
```
519.lbm_r small
1247 tokens to be augmented
Data Construction Time: 2.34
Train = 1 Val = 1 Test = 1
Input Size = 47 Hidden Size = 1000 Learning Rate = 0.001
Epoch 1/20, Loss: 0.0234
Epoch 2/20, Loss: 0.0198
...
Training Time: 45.67
Correct = 1156 total = 1289 Accuracy: 89.68%
```

**What it does**:
- **Profile Augmentation (4.4)**: Compares small profiles with medium/large profiles to extract unseen execution paths, creating unified training data
- **Sequence Prediction (4.5)**: Trains lightweight RNN models on augmented compressed profiles to predict next function calls in dynamic execution sequences
- **Model Training**: Uses one-hot encoded tensors, MSE loss, and Adam optimizer for sequence-to-sequence learning

### Stage 5: LLM-Based Application Behavior Synthesis - Dynamis (Supplementary Analysis)

**Purpose**: Generate compiler analysis to supplement LLM prompts for direct behavior inference from source code

```bash
# Test the LLM analysis pass (generates function mappings and loop analysis)
cd compilerPasses/testcodes
clang -emit-llvm -S test1.c -o test1.ll
opt -load ../build/LLMPass/libLLMPass.so --LLM -enable-new-pm=0 < test1.ll > test1_llm.bc
```

**Expected Output**:
```
Loop FuncID: 1
Loop FuncID: 3
***********************
FunctionName: main, ID: 0
FunctionName: function1, ID: 1
FunctionName: function2, ID: 2
***********************
```

**Note**: Due to resource constraints of LLM inference, this artifact provides the compiler analysis framework that supplements LLM prompts rather than actual LLM API calls. The `compilerPasses/LLMPass` extracts:
- Function names and ID mappings for prompt construction
- Loop structures and functions called within loops
- Reachable function analysis from main function
- Static program context that can be used to construct LLM prompts for behavior synthesis

### Expected Results Summary

1. **Profile Collection**: Compressed WPP profiles generated with online compression
2. **Static Analysis**: Function adjacency lists and control dependency mappings generated successfully
3. **Input-Consistent Compression**: 50-200× profile size reduction using path encodings
4. **Profile Augmentation & ML Training**: RNN models trained on augmented profiles achieving 85-95% prediction accuracy
5. **LLM Analysis Framework**: Compiler analysis framework for supplementing LLM prompts with static program context





## Reusability Guide

### Core Reusable Components

The artifact provides several reusable components for extending to new applications:

#### 1. LLVM Compiler Passes (`compilerPasses/`)
- **wholeProgramProfilePass**: Instruments programs for WPP collection
- **staticAnalysisPass**: Generates call graphs and control flow information
- **Reuse**: Extend to new LLVM-supported languages and optimization passes

#### 2. Profile Compression Framework (`compression/`)
- **dataCompress.py**: Core compression algorithm using static analysis
- **staticAnalysis.py**: Path encoding generation
- **Reuse**: Adapt compression dictionary and encoding schemes for new profile types

#### 3. ML Training Pipeline (`train/`)
- **models.py**: Vanilla RNN and extensible model architectures  
- **prepareData.py**: Data preprocessing and augmentation
- **train.py**: Training loop with hyperparameter configuration
- **Reuse**: Modify model architectures, add new sequence prediction models

#### 4. Evaluation Framework (`results/`)
- **Accuracy measurement**: Compare predictions with ground truth
- **Performance analysis**: Profile collection overhead measurement
- **Reuse**: Extend metrics and add new evaluation dimensions

### Adapting to New Inputs

#### New Benchmarks
1. **Profile Collection**: Use WPP pass to instrument new applications
2. **Static Analysis**: Generate call graphs with static analysis pass  
3. **Compression**: Run compression pipeline on collected profiles
4. **Training**: Use existing ML pipeline with new compressed data

#### New Programming Languages
1. **Extend LLVM passes**: Modify passes for language-specific constructs
2. **Update static analysis**: Adapt call graph generation for new language features
3. **Retrain models**: Use new profile data for model training

#### New Optimization Targets
1. **Profile different behaviors**: Modify instrumentation to track new metrics
2. **Extend compression**: Add new encoding schemes for different profile types
3. **Update models**: Train models for new prediction targets

### Documentation and Extension Points

#### Key Configuration Files
- `compilerPasses/CMakeLists.txt`: Build configuration for LLVM passes
- `compression/pathUtils.py`: File paths and directory structure
- `train/pathUtils.py`: Training data locations and model paths

#### Extension APIs
- **Model Architecture**: Inherit from `VanillaRNN` in `models.py`
- **Data Processing**: Extend functions in `prepareData.py`
- **Compression**: Add new encoding schemes in `compression/staticAnalysis.py`

#### Example Extension
```python
# Add new model architecture
class TransformerModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        # Implementation here
        pass

# Add new compression scheme  
def custom_compress(tokens, static_info):
    # Custom compression logic
    return compressed_tokens
```

### Limitations

1. **LLVM Dependency**: Currently tied to LLVM infrastructure; porting to other compilers requires significant changes
2. **Benchmark Coverage**: Optimized for SPEC CPU benchmarks; other benchmark suites may need adaptation
3. **Model Generalization**: RNN models may not generalize well to drastically different application domains
4. **Static Analysis Scope**: Limited to function-level analysis; finer-grained analysis requires pass modifications
5. **LLM Integration**: Direct LLM API integration not included; requires external implementation

### Getting Help

- **Code Documentation**: Inline comments in Python and C++ files
- **Configuration**: Modify path utilities in `pathUtils.py` files
- **Debugging**: Enable verbose output in training and compression scripts
- **Extension Examples**: Refer to existing benchmark implementations as templates

The artifact is designed to be modular and extensible, with clear separation between data collection, compression, training, and evaluation phases. Each component can be modified or replaced independently to support new research directions.

## LLVM 15 Installation Instructions

### Ubuntu/Debian:
```bash
# Add LLVM repository
wget -O - https://apt.llvm.org/llvm-snapshot.gpg.key | sudo apt-key add -
echo "deb http://apt.llvm.org/jammy/ llvm-toolchain-jammy-15 main" | sudo tee /etc/apt/sources.list.d/llvm.list

# Install LLVM 15
sudo apt-get update
sudo apt-get install llvm-15-dev llvm-15-tools clang-15 cmake build-essential

# Verify installation
llvm-config-15 --version
```

### macOS (using Homebrew):
```bash
# Install LLVM 15
brew install llvm@15

# Add to PATH (add to ~/.zshrc or ~/.bash_profile)
export PATH="/opt/homebrew/opt/llvm@15/bin:$PATH"
export LDFLAGS="-L/opt/homebrew/opt/llvm@15/lib"
export CPPFLAGS="-I/opt/homebrew/opt/llvm@15/include"

# Verify installation
llvm-config --version
```

### From Source:
```bash
# Download LLVM 15.0.0
wget https://github.com/llvm/llvm-project/releases/download/llvmorg-15.0.0/llvm-project-15.0.0.src.tar.xz
tar -xf llvm-project-15.0.0.src.tar.xz
cd llvm-project-15.0.0.src

# Build and install
mkdir build && cd build
cmake -DCMAKE_BUILD_TYPE=Release -DLLVM_ENABLE_PROJECTS="clang" ../llvm
make -j$(nproc)
sudo make install
``` 
